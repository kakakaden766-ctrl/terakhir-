Letakkan gambar untuk folder background di sini.
