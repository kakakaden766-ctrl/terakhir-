Letakkan gambar untuk folder banner di sini.
