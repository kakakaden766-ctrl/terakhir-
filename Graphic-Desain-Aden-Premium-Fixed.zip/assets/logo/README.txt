Letakkan gambar untuk folder logo di sini.
