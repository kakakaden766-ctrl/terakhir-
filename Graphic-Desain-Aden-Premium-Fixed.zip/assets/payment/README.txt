Letakkan gambar untuk folder payment di sini.
