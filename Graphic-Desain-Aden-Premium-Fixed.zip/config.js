/* =========================================================================
   CONFIG.JS — GRAPHIC DESAIN ADEN
   =========================================================================
   Semua pengaturan website ada di file ini.
   Ubah nilai di bawah ini untuk mengubah isi website tanpa menyentuh HTML.
   ========================================================================= */

const SITE_CONFIG = {

  // ------------------------------------------------------------------
  // INFORMASI DASAR WEBSITE
  // ------------------------------------------------------------------
  siteName: "Graphic Desain Aden",
  siteTagline: "Jasa Desain Digital Premium",
  logo: "assets/logo/logo.png",          // ganti dengan logo kamu
  favicon: "assets/logo/favicon.png",

  // ------------------------------------------------------------------
  // KONTAK & SOSIAL MEDIA
  // ------------------------------------------------------------------
  whatsappNumber: "6281234567890",       // format internasional tanpa "+"
  whatsappChannelLink: "https://whatsapp.com/channel/0029Vb5Zq9x6xCSOpl7Wku1r",
  tiktok: "https://tiktok.com/@graphicdesainaden",
  instagram: "https://instagram.com/graphicdesainaden",
  facebook: "https://facebook.com/graphicdesainaden",
  youtube: "https://youtube.com/@graphicdesainaden",
  telegram: "https://t.me/graphicdesainaden",

  // Pesan WhatsApp otomatis
  waMessageOrder: "Halo Admin Graphic Desain Aden, saya ingin memesan produk.",
  waMessageConfirm: "Halo Admin Graphic Desain Aden, saya sudah melakukan pembayaran. Berikut bukti pembayaran saya.",

  // ------------------------------------------------------------------
  // PEMBAYARAN
  // ------------------------------------------------------------------
  payment: {
    gopayNumber: "0812-3456-7890",
    danaNumber: "0812-3456-7890",
    ownerName: "Aden Saputra",
    qrisImage: "assets/payment/qris.png"
  },

  // ------------------------------------------------------------------
  // ADMIN (khusus demo frontend — bukan keamanan tingkat server)
  // ------------------------------------------------------------------
  admin: {
    username: "adenzyx",
    password: "adenzyx123",   // wajib diganti sebelum dipakai sungguhan
    name: "Aden"
  },

  // ------------------------------------------------------------------
  // TEMA WARNA (Biru Laut Cerah)
  // ------------------------------------------------------------------
  theme: {
    primary: "#00BFFF",
    primaryDark: "#1E40AF",
    accent: "#00BFFF",
    background: "#08111F"
  },

  // ------------------------------------------------------------------
  // COPYRIGHT
  // ------------------------------------------------------------------
  copyrightYear: 2026,
  copyrightText: "Graphic Desain Aden. Semua Hak Dilindungi."
};
