/* =========================================================================
   SCRIPT.JS — GRAPHIC DESAIN ADEN
   Vanilla JS (ES6). Tanpa framework. Semua data disimpan di LocalStorage
   untuk fitur keranjang, wishlist, dan dashboard admin (demo frontend).
   ========================================================================= */

/* ---------------------------------------------------------------------
   0. DATA DEFAULT TAMBAHAN (Banner, Kategori, Paket Sewa, Testimoni,
      Galeri, Cara Order) — silakan edit array di bawah ini untuk
      mengubah isi tanpa menyentuh HTML.
--------------------------------------------------------------------- */

const DEFAULT_BANNERS = [
  { id: "b1", image: "https://picsum.photos/seed/banner1/1900/600" },
  { id: "b2", image: "https://picsum.photos/seed/banner2/1900/600" },
  { id: "b3", image: "https://picsum.photos/seed/banner3/1900/600" }
];

const CATEGORIES = [
  { id: "logo",               label: "Logo",                icon: "fa-shield-halved" },
  { id: "skin-logo",          label: "Skin Logo",            icon: "fa-palette" },
  { id: "profil-qr",          label: "Profil QR",            icon: "fa-qrcode" },
  { id: "poster-roaster",     label: "Poster Roaster",       icon: "fa-image" },
  { id: "profil-jb",          label: "Profil JB",            icon: "fa-right-left" },
  { id: "banner-desain",      label: "Banner Desain",        icon: "fa-flag" },
  { id: "hosting",            label: "Hosting",              icon: "fa-cloud" },
  { id: "all-student",        label: "All Student",          icon: "fa-users" },
  { id: "apk-premium",        label: "Apk Premium",          icon: "fa-crown" },
  { id: "list-suntik-sosmed", label: "List Suntik Sosmed",   icon: "fa-share-nodes" }
];

const DEFAULT_PACKAGES = [
  { id: "pkg1", name: "Paket 1 Minggu", price: 150000, badge: "", popular: false, features: ["Unlimited Request","Unlimited Revisi","Format PNG, JPG, PSD","Prioritas Pengerjaan"] },
  { id: "pkg2", name: "Paket 2 Minggu", price: 280000, badge: "", popular: false, features: ["Unlimited Request","Unlimited Revisi","Semua Format File","Prioritas Tinggi"] },
  { id: "pkg3", name: "Paket 1 Bulan", price: 500000, badge: "⭐ Paling Populer", popular: true, features: ["Unlimited Request","Unlimited Revisi","Semua Format File","Bonus Banner","Bonus Thumbnail"] },
  { id: "pkg4", name: "Paket 2 Bulan", price: 900000, badge: "🔥 Best Value", popular: false, features: ["Semua fitur Paket 1 Bulan","Bonus Poster","Bonus Logo"] },
  { id: "pkg5", name: "Paket 3 Bulan", price: 1250000, badge: "", popular: false, features: ["Unlimited Request","Unlimited Revisi","Prioritas VIP","Bonus Desain Premium"] },
  { id: "pkg6", name: "Paket 4 Bulan", price: 1600000, badge: "", popular: false, features: ["Semua Bonus","Prioritas Super VIP"] },
  { id: "pkg7", name: "Paket 5 Bulan", price: 1900000, badge: "💎 Paket Hemat", popular: false, features: ["Unlimited Request","Unlimited Revisi","Semua Format File","Semua Bonus Aktif","Prioritas Tertinggi","Konsultasi Gratis"] }
];

const DEFAULT_TESTIMONIALS = [
  { id: "t1", name: "Rizky A.", photo: "https://picsum.photos/seed/cust1/100/100", result: "https://picsum.photos/seed/result1/400/240", comment: "Logo guild saya jadi keren banget, pengerjaan cepat!", rating: 5 },
  { id: "t2", name: "Dinda P.", photo: "https://picsum.photos/seed/cust2/100/100", result: "https://picsum.photos/seed/result2/400/240", comment: "Poster turnamen rapi dan sesuai request.", rating: 5 },
  { id: "t3", name: "Fajar S.", photo: "https://picsum.photos/seed/cust3/100/100", result: "https://picsum.photos/seed/result3/400/240", comment: "Admin ramah, hasil desain memuaskan.", rating: 4 },
  { id: "t4", name: "Nadia R.", photo: "https://picsum.photos/seed/cust4/100/100", result: "https://picsum.photos/seed/result4/400/240", comment: "Skin guild-nya unik, beda dari yang lain.", rating: 5 },
  { id: "t5", name: "Bagus W.", photo: "https://picsum.photos/seed/cust5/100/100", result: "https://picsum.photos/seed/result5/400/240", comment: "Harga terjangkau untuk kualitas sebagus ini.", rating: 5 },
  { id: "t6", name: "Sari M.", photo: "https://picsum.photos/seed/cust6/100/100", result: "https://picsum.photos/seed/result6/400/240", comment: "Sewa desain sebulan sangat worth it.", rating: 5 },
  { id: "t7", name: "Yoga T.", photo: "https://picsum.photos/seed/cust7/100/100", result: "https://picsum.photos/seed/result7/400/240", comment: "Revisi cepat direspon, hasil akhir mantap.", rating: 4 },
  { id: "t8", name: "Intan K.", photo: "https://picsum.photos/seed/cust8/100/100", result: "https://picsum.photos/seed/result8/400/240", comment: "Akun game yang dibeli sesuai deskripsi.", rating: 5 },
  { id: "t9", name: "Doni H.", photo: "https://picsum.photos/seed/cust9/100/100", result: "https://picsum.photos/seed/result9/400/240", comment: "Hosting stabil, proses pembelian mudah.", rating: 4 },
  { id: "t10", name: "Melati F.", photo: "https://picsum.photos/seed/cust10/100/100", result: "https://picsum.photos/seed/result10/400/240", comment: "Pelayanan ramah dan hasil selalu on time.", rating: 5 }
];

const DEFAULT_GALLERY = (() => {
  const cats = ["Logo Guild","Poster","Skin Guild","Banner","Thumbnail","Hosting","Akun Game"];
  const items = [];
  for (let i = 1; i <= 30; i++) {
    const cat = cats[i % cats.length];
    items.push({
      id: "g" + i,
      category: cat,
      image: `https://picsum.photos/seed/gallery${i}/500/${350 + (i % 4) * 60}`
    });
  }
  return items;
})();

const ORDER_STEPS = [
  { icon: "fa-bag-shopping", text: "Pilih Produk" },
  { icon: "fa-cart-plus", text: "Tambahkan ke Keranjang" },
  { icon: "fa-clipboard-list", text: "Checkout" },
  { icon: "fa-wallet", text: "Pilih GoPay / DANA / QRIS" },
  { icon: "fa-money-bill-wave", text: "Lakukan Pembayaran" },
  { icon: "fa-upload", text: "Upload Bukti Pembayaran" },
  { icon: "fa-brands fa-whatsapp", text: "Hubungi Admin" },
  { icon: "fa-gears", text: "Pesanan Diproses" },
  { icon: "fa-file-export", text: "File Hasil Dikirim" }
];

/* ---------------------------------------------------------------------
   1. STATE & PENYIMPANAN LOKAL (LocalStorage)
--------------------------------------------------------------------- */
let ALL_PRODUCTS = [];
let currentCategory = "all";
let currentPage = 1;
const PAGE_SIZE = 16;

const Storage = {
  get(key, fallback) {
    try {
      const v = localStorage.getItem(key);
      return v ? JSON.parse(v) : fallback;
    } catch (e) { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* storage full/unavailable */ }
  }
};

let cart = Storage.get("gda_cart", []);
let wishlist = Storage.get("gda_wishlist", []);
let localOrders = Storage.get("gda_orders", []);

function saveCart() { Storage.set("gda_cart", cart); updateCartUI(); }
function saveWishlist() { Storage.set("gda_wishlist", wishlist); }

/* ---------------------------------------------------------------------
   1B. KONTEN YANG BISA DIEDIT ADMIN (Banner, Galeri, Testimoni, Teks
   Halaman, Pengaturan Situs & Pembayaran) — semua disimpan permanen di
   LocalStorage browser admin ini lewat Dashboard, tanpa perlu edit kode.
--------------------------------------------------------------------- */
let BANNERS = [];          // working array banner (hasil merge admin)
let GALLERY_ITEMS = [];    // working array galeri (hasil merge admin)
let TESTIMONIALS = [];     // working array testimoni (hasil merge admin)
let PACKAGES = [];         // working array paket sewa desain (hasil edit admin)

function loadPackages() {
  const saved = Storage.get("gda_packages", null);
  PACKAGES = saved && saved.length ? saved : DEFAULT_PACKAGES.map(p => ({ ...p, features: [...p.features] }));
}
function savePackages() { Storage.set("gda_packages", PACKAGES); }
function savePackageOverride(id, fields) {
  const pkg = PACKAGES.find(p => p.id === id);
  if (pkg) Object.assign(pkg, fields);
  savePackages();
}
function deletePackage(id) {
  PACKAGES = PACKAGES.filter(p => p.id !== id);
  savePackages();
}
function addPackage(fields) {
  const id = "pkg-" + Date.now();
  PACKAGES.push({ id, name: fields.name, price: fields.price, badge: fields.badge || "", popular: !!fields.popular, features: fields.features || [] });
  savePackages();
  return id;
}
function resetPackagesToDefault() {
  PACKAGES = DEFAULT_PACKAGES.map(p => ({ ...p, features: [...p.features] }));
  savePackages();
}

function loadBanners() {
  const saved = Storage.get("gda_banners", null);
  BANNERS = saved && saved.length ? saved : DEFAULT_BANNERS.map(b => ({ ...b }));
}
function saveBanners() { Storage.set("gda_banners", BANNERS); }

function loadGallery() {
  const deleted = Storage.get("gda_gallery_deleted", []);
  const overrides = Storage.get("gda_gallery_overrides", {});
  const custom = Storage.get("gda_gallery_custom", []);
  const base = DEFAULT_GALLERY.filter(g => !deleted.includes(g.id)).map(g => ({ ...g, ...(overrides[g.id] || {}) }));
  GALLERY_ITEMS = base.concat(custom);
}
function saveGalleryCustom(list) { Storage.set("gda_gallery_custom", list); }
function saveGalleryOverride(id, fields) {
  const overrides = Storage.get("gda_gallery_overrides", {});
  overrides[id] = { ...(overrides[id] || {}), ...fields };
  Storage.set("gda_gallery_overrides", overrides);
}
function deleteGalleryItem(id) {
  if (id.toString().startsWith("custom-")) {
    const custom = Storage.get("gda_gallery_custom", []).filter(g => g.id !== id);
    saveGalleryCustom(custom);
  } else {
    const deleted = Storage.get("gda_gallery_deleted", []);
    if (!deleted.includes(id)) deleted.push(id);
    Storage.set("gda_gallery_deleted", deleted);
  }
  loadGallery();
}

function loadTestimonials() {
  const deleted = Storage.get("gda_testi_deleted", []);
  const overrides = Storage.get("gda_testi_overrides", {});
  const custom = Storage.get("gda_testi_custom", []);
  const base = DEFAULT_TESTIMONIALS.filter(t => !deleted.includes(t.id)).map(t => ({ ...t, ...(overrides[t.id] || {}) }));
  TESTIMONIALS = base.concat(custom);
}
function saveTestiCustom(list) { Storage.set("gda_testi_custom", list); }
function saveTestiOverride(id, fields) {
  const overrides = Storage.get("gda_testi_overrides", {});
  overrides[id] = { ...(overrides[id] || {}), ...fields };
  Storage.set("gda_testi_overrides", overrides);
}
function deleteTestiItem(id) {
  if (id.toString().startsWith("custom-")) {
    const custom = Storage.get("gda_testi_custom", []).filter(t => t.id !== id);
    saveTestiCustom(custom);
  } else {
    const deleted = Storage.get("gda_testi_deleted", []);
    if (!deleted.includes(id)) deleted.push(id);
    Storage.set("gda_testi_deleted", deleted);
  }
  loadTestimonials();
}

/* Pengaturan situs & pembayaran (menimpa SITE_CONFIG dari config.js) */
function loadSiteOverrides() {
  const overrides = Storage.get("gda_site_overrides", null);
  if (!overrides) return;
  Object.keys(overrides).forEach(key => {
    if (typeof overrides[key] === "object" && overrides[key] !== null && !Array.isArray(overrides[key])) {
      SITE_CONFIG[key] = { ...SITE_CONFIG[key], ...overrides[key] };
    } else {
      SITE_CONFIG[key] = overrides[key];
    }
  });
}
function saveSiteOverride(fields) {
  const overrides = Storage.get("gda_site_overrides", {});
  Object.keys(fields).forEach(key => {
    if (typeof fields[key] === "object" && fields[key] !== null && !Array.isArray(fields[key])) {
      overrides[key] = { ...(overrides[key] || {}), ...fields[key] };
    } else {
      overrides[key] = fields[key];
    }
  });
  Storage.set("gda_site_overrides", overrides);
  loadSiteOverrides();
}

/* Teks halaman: Judul Hero, Subjudul Hero, Teks Tentang Kami */
const DEFAULT_PAGE_TEXT = {
  heroTitle: "SELAMAT DATANG DI GRAPHIC DESAIN ADEN",
  heroSubtitle: "Melayani jasa desain logo profesional, skin guild, poster desain, kebutuhan hosting, produk akun game, serta layanan sewa desain dengan kualitas premium dan harga terjangkau.",
  aboutText: "Graphic Desain Aden merupakan penyedia jasa desain digital profesional yang melayani pembuatan logo, poster, skin guild, kebutuhan hosting, produk akun game, dan berbagai kebutuhan desain lainnya dengan kualitas premium, pengerjaan cepat, serta harga yang terjangkau.",
  sewaTitle: "Sewa Desain",
  sewaSubtitle: "Pilih paket sewa desain sesuai kebutuhanmu — unlimited request & revisi.",
  estimasiPengerjaan: "1–3 jam kerja tergantung kesulitan desain",
  revisiText: "gratis revisi",
  bonusText: "appear as a testimonial"
};
function getPageText() {
  return { ...DEFAULT_PAGE_TEXT, ...Storage.get("gda_page_text", {}) };
}
function savePageText(fields) {
  const current = Storage.get("gda_page_text", {});
  Storage.set("gda_page_text", { ...current, ...fields });
  applyPageText();
}
function applyPageText() {
  const t = getPageText();
  document.getElementById("heroTitleText").textContent = t.heroTitle;
  document.getElementById("heroSubtitleText").textContent = t.heroSubtitle;
  document.querySelectorAll(".about-text-el").forEach(el => { el.textContent = t.aboutText; });
  const sewaTitleEl = document.getElementById("sewaPageTitle");
  const sewaSubEl = document.getElementById("sewaPageSub");
  if (sewaTitleEl) sewaTitleEl.textContent = t.sewaTitle;
  if (sewaSubEl) sewaSubEl.textContent = t.sewaSubtitle;
}

/* ---------------------------------------------------------------------
   2. UTILITAS
--------------------------------------------------------------------- */
function formatRupiah(num) {
  return "Rp" + Number(num).toLocaleString("id-ID");
}

function showToast(message, icon = "fa-circle-check") {
  const container = document.getElementById("toastContainer");
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.innerHTML = `<i class="fa-solid ${icon}"></i> ${message}`;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 2600);
}

function waLink(message) {
  const number = SITE_CONFIG.whatsappNumber;
  return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}

function starIcons(rating) {
  return "★".repeat(rating) + "☆".repeat(5 - rating);
}

/* ---------------------------------------------------------------------
   3. ROUTER SEDERHANA (hash-based single page navigation)
--------------------------------------------------------------------- */
function goToPage(pageId) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  const target = document.getElementById("page-" + pageId);
  if (target) target.classList.add("active");
  window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  document.getElementById("navMenu").classList.remove("open");
}

document.addEventListener("click", (e) => {
  const link = e.target.closest("[data-page]");
  if (link) {
    e.preventDefault();
    goToPage(link.dataset.page);
    if (link.dataset.cat) {
      currentCategory = link.dataset.cat;
      renderCategoryTabs();
      renderCatalog();
    }
  }
});

/* ---------------------------------------------------------------------
   4. NAVBAR (scroll effect + mobile toggle)
--------------------------------------------------------------------- */
window.addEventListener("scroll", () => {
  const nav = document.getElementById("navbar");
  nav.classList.toggle("scrolled", window.scrollY > 40);

  const backTop = document.getElementById("backToTopBtn");
  backTop.classList.toggle("show", window.scrollY > 500);
});

document.getElementById("navToggle").addEventListener("click", () => {
  document.getElementById("navMenu").classList.toggle("open");
});

document.getElementById("backToTopBtn").addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

/* ---------------------------------------------------------------------
   5. APPLY CONFIG (nama situs, logo, sosial media, dsb)
--------------------------------------------------------------------- */
function applyConfig() {
  document.getElementById("navSiteName").textContent = SITE_CONFIG.siteName;
  document.getElementById("footerSiteName").textContent = SITE_CONFIG.siteName;
  document.getElementById("footerCopyright").textContent = SITE_CONFIG.copyrightText;
  document.getElementById("footerYear").textContent = SITE_CONFIG.copyrightYear;
  document.title = SITE_CONFIG.siteName + " — " + SITE_CONFIG.siteTagline;
  const FALLBACK_LOGO = "https://picsum.photos/seed/logo-aden/60/60";
  const navLogoImg = document.getElementById("navLogoImg");
  if (SITE_CONFIG.logo && navLogoImg) {
    navLogoImg.onerror = () => { navLogoImg.onerror = null; navLogoImg.src = FALLBACK_LOGO; };
    navLogoImg.src = SITE_CONFIG.logo;
  }
  const faviconEl = document.querySelector("link[rel='icon']");
  if (SITE_CONFIG.favicon && faviconEl) {
    // cek dulu apakah file favicon ada; kalau tidak, biarkan favicon bawaan (tidak diganti ke rusak)
    const testImg = new Image();
    testImg.onload = () => { faviconEl.href = SITE_CONFIG.favicon; };
    testImg.onerror = () => { /* file belum ada, favicon dibiarkan seperti semula */ };
    testImg.src = SITE_CONFIG.favicon;
  }

  const socialLinks = [
    { url: SITE_CONFIG.whatsappNumber ? `https://wa.me/${SITE_CONFIG.whatsappNumber}` : "#", icon: "fa-brands fa-whatsapp" },
    { url: SITE_CONFIG.whatsappChannelLink, icon: "fa-brands fa-whatsapp" },
    { url: SITE_CONFIG.tiktok, icon: "fa-brands fa-tiktok" },
    { url: SITE_CONFIG.instagram, icon: "fa-brands fa-instagram" },
    { url: SITE_CONFIG.facebook, icon: "fa-brands fa-facebook" },
    { url: SITE_CONFIG.youtube, icon: "fa-brands fa-youtube" },
    { url: SITE_CONFIG.telegram, icon: "fa-brands fa-telegram" }
  ];
  const socialHtml = socialLinks.map(s => `<a href="${s.url}" target="_blank" rel="noopener"><i class="${s.icon}"></i></a>`).join("");
  document.getElementById("footerSocial").innerHTML = socialHtml;
  document.getElementById("kontakSocial").innerHTML = socialHtml;
}

/* ---------------------------------------------------------------------
   6. HERO BANNER SLIDER
--------------------------------------------------------------------- */
let heroIndex = 0;
let heroTimer = null;

function renderHero() {
  const hero = document.getElementById("hero");
  const indicators = document.getElementById("heroIndicators");
  // hapus slide lama (kalau ada), sisipkan sebelum overlay
  hero.querySelectorAll(".hero-slide").forEach(s => s.remove());
  indicators.innerHTML = "";

  BANNERS.forEach((b, i) => {
    const slide = document.createElement("div");
    slide.className = "hero-slide" + (i === 0 ? " active" : "");
    slide.style.backgroundImage = `url('${b.image}')`;
    hero.insertBefore(slide, hero.firstChild);

    const dot = document.createElement("div");
    dot.className = "hero-dot" + (i === 0 ? " active" : "");
    dot.addEventListener("click", () => setHeroSlide(i));
    indicators.appendChild(dot);
  });

  startHeroAutoSlide();
}

function setHeroSlide(index) {
  const slides = document.querySelectorAll(".hero-slide");
  const dots = document.querySelectorAll(".hero-dot");
  heroIndex = (index + slides.length) % slides.length;
  slides.forEach(s => s.classList.remove("active"));
  dots.forEach(d => d.classList.remove("active"));
  slides[heroIndex].classList.add("active");
  dots[heroIndex].classList.add("active");
}

function startHeroAutoSlide() {
  clearInterval(heroTimer);
  heroTimer = setInterval(() => setHeroSlide(heroIndex + 1), 5000);
}

document.getElementById("heroNext").addEventListener("click", () => { setHeroSlide(heroIndex + 1); startHeroAutoSlide(); });
document.getElementById("heroPrev").addEventListener("click", () => { setHeroSlide(heroIndex - 1); startHeroAutoSlide(); });

/* ---------------------------------------------------------------------
   7. KATEGORI CEPAT
--------------------------------------------------------------------- */
function renderQuickCategories() {
  const wrap = document.getElementById("quickCategories");
  wrap.innerHTML = CATEGORIES.map(c => `
    <a href="#produk" data-page="produk" data-cat="${c.id}" class="quick-cat">
      <div class="icon-circle"><i class="fa-solid ${c.icon}"></i></div>
      <span>${c.label}</span>
    </a>
  `).join("");
}

/* ---------------------------------------------------------------------
   8. KARTU PRODUK (dipakai di semua grid)
--------------------------------------------------------------------- */
function productCardHtml(p) {
  const isWished = wishlist.includes(p.id);
  const badges = [];
  if (p.bestSeller) badges.push(`<span class="badge badge-bestseller">🔥 Terlaris</span>`);
  if (p.isNew) badges.push(`<span class="badge badge-new">🆕 Baru</span>`);
  if (p.promo) badges.push(`<span class="badge badge-promo">💰 Promo</span>`);

  return `
  <div class="card" data-id="${p.id}">
    <div class="card-badges">${badges.join("")}</div>
    <button class="wishlist-btn ${isWished ? "active" : ""}" data-wish="${p.id}"><i class="fa-solid fa-heart"></i></button>
    <div class="card-img-wrap" data-detail="${p.id}">
      <img src="${p.image}" alt="${p.name}" loading="lazy">
    </div>
    <div class="card-body">
      <span class="card-cat">${categoryLabel(p.category)}</span>
      <span class="card-title">${p.name}</span>
      <span class="card-rating">${starIcons(p.rating || 5)}</span>
      <span class="card-price">${formatRupiah(p.price)}</span>
      <div class="card-actions">
        <button class="btn btn-detail" data-detail="${p.id}">Detail</button>
        <button class="btn btn-cart" data-addcart="${p.id}"><i class="fa-solid fa-cart-plus"></i></button>
      </div>
    </div>
  </div>`;
}

function categoryLabel(id) {
  const found = CATEGORIES.find(c => c.id === id);
  return found ? found.label : id;
}

/* Delegasi klik untuk semua tombol di dalam card produk */
document.addEventListener("click", (e) => {
  const wishBtn = e.target.closest("[data-wish]");
  if (wishBtn) {
    toggleWishlist(wishBtn.dataset.wish);
    return;
  }
  const detailBtn = e.target.closest("[data-detail]");
  if (detailBtn) {
    openProductDetail(detailBtn.dataset.detail);
    return;
  }
  const cartBtn = e.target.closest("[data-addcart]");
  if (cartBtn) {
    addToCart(cartBtn.dataset.addcart, 1);
    return;
  }
});

function toggleWishlist(id) {
  if (wishlist.includes(id)) {
    wishlist = wishlist.filter(w => w !== id);
    showToast("Dihapus dari wishlist", "fa-heart-crack");
  } else {
    wishlist.push(id);
    showToast("Ditambahkan ke wishlist", "fa-heart");
  }
  saveWishlist();
  document.querySelectorAll(`[data-wish="${id}"]`).forEach(btn => btn.classList.toggle("active"));
  document.getElementById("wishlistCount").textContent = wishlist.length;
  if (document.getElementById("wishlistFilter").value === "wishlist") renderCatalog();
}

/* ---------------------------------------------------------------------
   9. HOME: PRODUK TERBARU & TERLARIS
--------------------------------------------------------------------- */
function renderHomeGrids() {
  const newest = [...ALL_PRODUCTS].filter(p => p.isNew).concat([...ALL_PRODUCTS]).slice(0, 8);
  const uniqueNewest = Array.from(new Map(newest.map(p => [p.id, p])).values()).slice(0, 8);
  document.getElementById("newestGrid").innerHTML = uniqueNewest.map(productCardHtml).join("");

  const bestSellers = ALL_PRODUCTS.filter(p => p.bestSeller).slice(0, 8);
  document.getElementById("bestSellerGrid").innerHTML = bestSellers.map(productCardHtml).join("");
}

/* ---------------------------------------------------------------------
   10. KATALOG PRODUK (Filter, Search, Sort, Pagination)
--------------------------------------------------------------------- */
function renderCategoryTabs() {
  const tabs = document.getElementById("categoryTabs");
  const all = [{ id: "all", label: "Semua" }, ...CATEGORIES];
  tabs.innerHTML = all.map(c => `
    <button class="tab-btn ${currentCategory === c.id ? "active" : ""}" data-tab-cat="${c.id}">${c.label}</button>
  `).join("");
  tabs.querySelectorAll("[data-tab-cat]").forEach(btn => {
    btn.addEventListener("click", () => {
      currentCategory = btn.dataset.tabCat;
      currentPage = 1;
      renderCategoryTabs();
      renderCatalog();
    });
  });
}

function getFilteredProducts() {
  let list = [...ALL_PRODUCTS];

  if (currentCategory !== "all") list = list.filter(p => p.category === currentCategory);

  const search = document.getElementById("searchInput").value.trim().toLowerCase();
  if (search) list = list.filter(p => p.name.toLowerCase().includes(search));

  if (document.getElementById("wishlistFilter").value === "wishlist") {
    list = list.filter(p => wishlist.includes(p.id));
  }

  const sort = document.getElementById("sortSelect").value;
  if (sort === "price-asc") list.sort((a, b) => a.price - b.price);
  else if (sort === "price-desc") list.sort((a, b) => b.price - a.price);
  else if (sort === "bestseller") list.sort((a, b) => (b.bestSeller ? 1 : 0) - (a.bestSeller ? 1 : 0));
  else if (sort === "newest") list.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));

  return list;
}

function renderCatalog() {
  const list = getFilteredProducts();
  document.getElementById("resultCount").textContent = `Ditemukan ${list.length} produk`;

  const totalPages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
  if (currentPage > totalPages) currentPage = totalPages;
  const start = (currentPage - 1) * PAGE_SIZE;
  const pageItems = list.slice(start, start + PAGE_SIZE);

  document.getElementById("catalogGrid").innerHTML = pageItems.length
    ? pageItems.map(productCardHtml).join("")
    : `<p class="empty-state" style="grid-column:1/-1;">Tidak ada produk ditemukan.</p>`;

  const pag = document.getElementById("pagination");
  pag.innerHTML = "";
  for (let i = 1; i <= totalPages; i++) {
    const btn = document.createElement("button");
    btn.className = "page-btn" + (i === currentPage ? " active" : "");
    btn.textContent = i;
    btn.addEventListener("click", () => { currentPage = i; renderCatalog(); window.scrollTo({top:0,behavior:"smooth"}); });
    pag.appendChild(btn);
  }
}

["searchInput"].forEach(id => {
  document.getElementById(id).addEventListener("input", () => { currentPage = 1; renderCatalog(); });
});
["sortSelect", "wishlistFilter"].forEach(id => {
  document.getElementById(id).addEventListener("change", () => { currentPage = 1; renderCatalog(); });
});

/* ---------------------------------------------------------------------
   11. DETAIL PRODUK (Modal)
--------------------------------------------------------------------- */
function openProductDetail(id) {
  const p = ALL_PRODUCTS.find(x => x.id === id);
  if (!p) return;
  const pt = getPageText();
  const modal = document.getElementById("productModal");
  const box = document.getElementById("productModalBox");

  box.innerHTML = `
    <button class="modal-close" id="productModalCloseBtn"><i class="fa-solid fa-xmark"></i></button>
    <img src="${p.image}" alt="${p.name}" class="product-detail-img">
    <div class="product-detail-body">
      <h2>${p.name}</h2>
      <div class="detail-meta">
        <span><i class="fa-solid fa-tag"></i> ${categoryLabel(p.category)}</span>
        <span class="card-rating">${starIcons(p.rating || 5)}</span>
      </div>
      <p class="card-price" style="font-size:1.3rem;">${formatRupiah(p.price)}</p>
      <p style="color:var(--text-muted);font-size:0.88rem;margin-top:8px;">${p.description}</p>
      <p style="font-size:0.8rem;margin-top:10px;"><strong>Estimasi pengerjaan:</strong> ${pt.estimasiPengerjaan}</p>
      <p style="font-size:0.8rem;"><strong>Revisi:</strong> ${pt.revisiText}</p>
      <p style="font-size:0.8rem;"><strong>Bonus:</strong> ${pt.bonusText}</p>
      <div class="format-tags">
        <span>PNG</span><span>JPG</span><span>PSD</span><span>AI</span><span>CDR</span><span>SVG</span>
      </div>
      <div class="detail-actions">
        <button class="btn btn-primary" data-addcart="${p.id}"><i class="fa-solid fa-cart-plus"></i> Tambah Keranjang</button>
        <button class="btn btn-outline" style="background:#25D366;border:none;color:white;" id="detailWaBtn"><i class="fa-brands fa-whatsapp"></i> Pesan via WhatsApp</button>
      </div>
    </div>
  `;

  box.querySelector("#productModalCloseBtn").addEventListener("click", closeAllModals);
  box.querySelector("#detailWaBtn").addEventListener("click", () => {
    window.open(waLink(`Halo Admin Graphic Desain Aden, saya ingin memesan produk "${p.name}" seharga ${formatRupiah(p.price)}.`), "_blank");
  });

  modal.classList.add("open");
}

function closeAllModals() {
  document.querySelectorAll(".modal-overlay").forEach(m => m.classList.remove("open"));
}
document.querySelectorAll(".modal-overlay").forEach(overlay => {
  overlay.addEventListener("click", (e) => { if (e.target === overlay) closeAllModals(); });
});

/* ---------------------------------------------------------------------
   12. KERANJANG BELANJA (LocalStorage)
--------------------------------------------------------------------- */
function addToCart(id, qty) {
  const existing = cart.find(c => c.id === id);
  if (existing) existing.qty += qty;
  else cart.push({ id, qty, selected: true });
  saveCart();
  showToast("Produk ditambahkan ke keranjang", "fa-cart-plus");
}

function updateCartUI() {
  const count = cart.reduce((sum, c) => sum + c.qty, 0);
  document.getElementById("cartCount").textContent = count;
  document.getElementById("fabCartCount").textContent = count;
  document.getElementById("wishlistCount").textContent = wishlist.length;
  renderCartPanel();
}

function renderCartPanel() {
  const list = document.getElementById("cartItemsList");
  if (!cart.length) {
    list.innerHTML = `<p class="empty-state"><i class="fa-solid fa-cart-shopping" style="font-size:1.6rem;display:block;margin-bottom:8px;"></i>Keranjang kamu masih kosong.</p>`;
    document.getElementById("cartGrandTotal").textContent = formatRupiah(0);
    return;
  }

  list.innerHTML = cart.map(item => {
    const p = ALL_PRODUCTS.find(x => x.id === item.id);
    if (!p) return "";
    return `
    <div class="cart-item">
      <input type="checkbox" class="cart-select" data-select="${item.id}" ${item.selected ? "checked" : ""}>
      <img src="${p.image}" alt="${p.name}">
      <div class="cart-item-info">
        <h5>${p.name}</h5>
        <span style="font-size:0.78rem;color:var(--text-muted);">${formatRupiah(p.price)}</span>
        <div class="qty-control">
          <button data-qty="${item.id}" data-dir="-1">−</button>
          <span>${item.qty}</span>
          <button data-qty="${item.id}" data-dir="1">+</button>
        </div>
      </div>
      <button data-remove="${item.id}" style="color:#ef476f;"><i class="fa-solid fa-trash"></i></button>
    </div>`;
  }).join("");

  const total = cart.filter(c => c.selected).reduce((sum, c) => {
    const p = ALL_PRODUCTS.find(x => x.id === c.id);
    return sum + (p ? p.price * c.qty : 0);
  }, 0);
  document.getElementById("cartGrandTotal").textContent = formatRupiah(total);
}

document.addEventListener("click", (e) => {
  const qtyBtn = e.target.closest("[data-qty]");
  if (qtyBtn) {
    const item = cart.find(c => c.id === qtyBtn.dataset.qty);
    const dir = Number(qtyBtn.dataset.dir);
    if (item) {
      item.qty = Math.max(1, item.qty + dir);
      saveCart();
    }
    return;
  }
  const removeBtn = e.target.closest("[data-remove]");
  if (removeBtn) {
    cart = cart.filter(c => c.id !== removeBtn.dataset.remove);
    saveCart();
    return;
  }
  const selectBox = e.target.closest("[data-select]");
  if (selectBox) {
    const item = cart.find(c => c.id === selectBox.dataset.select);
    if (item) item.selected = selectBox.checked;
    saveCart();
    return;
  }
});

document.getElementById("selectAllBtn").addEventListener("change", (e) => {
  cart.forEach(c => c.selected = e.target.checked);
  saveCart();
});
document.getElementById("clearCartBtn").addEventListener("click", () => {
  cart = [];
  saveCart();
  showToast("Keranjang dikosongkan", "fa-trash");
});

function openCartPanel() {
  document.getElementById("cartPanel").classList.add("open");
  document.getElementById("cartOverlay").classList.add("open");
}
function closeCartPanel() {
  document.getElementById("cartPanel").classList.remove("open");
  document.getElementById("cartOverlay").classList.remove("open");
}
document.getElementById("cartNavBtn").addEventListener("click", openCartPanel);
document.getElementById("fabCartBtn").addEventListener("click", openCartPanel);
document.getElementById("cartCloseBtn").addEventListener("click", closeCartPanel);
document.getElementById("cartOverlay").addEventListener("click", closeCartPanel);

document.getElementById("goCheckoutBtn").addEventListener("click", () => {
  if (!cart.filter(c => c.selected).length) {
    showToast("Pilih minimal satu produk dahulu", "fa-triangle-exclamation");
    return;
  }
  closeCartPanel();
  renderCheckoutSummary();
  goToPage("checkout");
});

document.getElementById("wishlistNavBtn").addEventListener("click", () => {
  goToPage("produk");
  document.getElementById("wishlistFilter").value = "wishlist";
  currentPage = 1;
  renderCatalog();
});

/* ---------------------------------------------------------------------
   13. PAKET SEWA DESAIN
--------------------------------------------------------------------- */
function renderPackages() {
  const grid = document.getElementById("packageGrid");
  grid.innerHTML = PACKAGES.map(pkg => `
    <div class="package-card ${pkg.popular ? "popular" : ""}">
      ${pkg.badge ? `<div class="package-badge">${pkg.badge}</div>` : ""}
      <div class="package-name">${pkg.name}</div>
      <div class="package-price">${formatRupiah(pkg.price)}</div>
      <ul class="package-features">
        ${pkg.features.map(f => `<li><i class="fa-solid fa-circle-check"></i> ${f}</li>`).join("")}
      </ul>
      <div class="package-actions">
        <button class="btn btn-primary" data-package-cart="${pkg.name}" data-price="${pkg.price}">🛒 Tambah Keranjang</button>
        <button class="btn btn-outline" style="background:rgba(2,136,209,0.12);color:var(--primary-dark);" data-package-wa="${pkg.name}" data-price="${pkg.price}">📅 Sewa Sekarang</button>
      </div>
    </div>
  `).join("");
}

document.addEventListener("click", (e) => {
  const pkgCartBtn = e.target.closest("[data-package-cart]");
  if (pkgCartBtn) {
    const id = "package-" + pkgCartBtn.dataset.packageCart.replace(/\s+/g, "-").toLowerCase();
    if (!ALL_PRODUCTS.find(p => p.id === id)) {
      ALL_PRODUCTS.push({
        id, name: pkgCartBtn.dataset.packageCart, category: "sewa-desain",
        price: Number(pkgCartBtn.dataset.price),
        image: "https://picsum.photos/seed/sewa-desain/600/600",
        description: "Paket sewa desain Graphic Desain Aden.", rating: 5
      });
    }
    addToCart(id, 1);
    return;
  }
  const pkgWaBtn = e.target.closest("[data-package-wa]");
  if (pkgWaBtn) {
    window.open(waLink(`Halo Admin Graphic Desain Aden, saya ingin sewa desain paket "${pkgWaBtn.dataset.packageWa}" seharga ${formatRupiah(pkgWaBtn.dataset.price)}.`), "_blank");
    return;
  }
});

/* ---------------------------------------------------------------------
   14. TESTIMONI SLIDER
--------------------------------------------------------------------- */
function testiCardHtml(t) {
  return `
    <div class="testi-card">
      <img src="${t.photo}" alt="${t.name}" class="testi-photo">
      <div class="testi-name">${t.name}</div>
      <div class="testi-verified"><i class="fa-solid fa-circle-check"></i> Verified Buyer</div>
      <div class="testi-rating">${starIcons(t.rating)}</div>
      <p class="testi-comment">"${t.comment}"</p>
      <img src="${t.result}" alt="Hasil desain" class="testi-result-img">
    </div>
  `;
}

let testiIndexFull = 0;
function renderTestimonials() {
  document.getElementById("testiTrackHome").innerHTML = TESTIMONIALS.slice(0, 5).map(testiCardHtml).join("");
  document.getElementById("testiTrackFull").innerHTML = TESTIMONIALS.map(testiCardHtml).join("");
}
function slideTestiFull(dir) {
  const track = document.getElementById("testiTrackFull");
  const cardWidth = track.firstElementChild ? track.firstElementChild.getBoundingClientRect().width : 300;
  testiIndexFull = Math.max(0, Math.min(TESTIMONIALS.length - 1, testiIndexFull + dir));
  track.style.transform = `translateX(-${testiIndexFull * cardWidth}px)`;
}
document.getElementById("testiPrev").addEventListener("click", () => slideTestiFull(-1));
document.getElementById("testiNext").addEventListener("click", () => slideTestiFull(1));

/* ---------------------------------------------------------------------
   15. GALERI (Masonry + Lightbox)
--------------------------------------------------------------------- */
let currentGalleryFilter = "Semua";
let lightboxIndex = 0;
let lightboxList = [];

function renderGalleryFilter() {
  const cats = ["Semua", ...new Set(GALLERY_ITEMS.map(g => g.category))];
  const wrap = document.getElementById("galleryFilter");
  wrap.innerHTML = cats.map(c => `<button class="tab-btn ${c === currentGalleryFilter ? "active" : ""}" data-gal-cat="${c}">${c}</button>`).join("");
  wrap.querySelectorAll("[data-gal-cat]").forEach(btn => {
    btn.addEventListener("click", () => {
      currentGalleryFilter = btn.dataset.galCat;
      renderGalleryFilter();
      renderGalleryGrid();
    });
  });
}

function renderGalleryGrid() {
  const list = currentGalleryFilter === "Semua" ? GALLERY_ITEMS : GALLERY_ITEMS.filter(g => g.category === currentGalleryFilter);
  lightboxList = list;
  document.getElementById("galleryGrid").innerHTML = list.map((g, i) => `
    <div class="masonry-item" data-gal-index="${i}">
      <img src="${g.image}" alt="${g.category}" loading="lazy">
      <div class="m-label">${g.category}</div>
    </div>
  `).join("");
}

function renderGalleryPreview() {
  document.getElementById("galleryPreview").innerHTML = GALLERY_ITEMS.slice(0, 8).map(g => `
    <div class="masonry-item"><img src="${g.image}" alt="${g.category}" loading="lazy"><div class="m-label">${g.category}</div></div>
  `).join("");
}

document.addEventListener("click", (e) => {
  const galItem = e.target.closest("[data-gal-index]");
  if (galItem) openLightbox(Number(galItem.dataset.galIndex));
});

function openLightbox(index) {
  lightboxIndex = index;
  document.getElementById("lightboxImg").src = lightboxList[index].image;
  document.getElementById("lightboxModal").classList.add("open");
}
document.getElementById("lightboxClose").addEventListener("click", closeAllModals);
document.getElementById("lightboxPrev").addEventListener("click", () => {
  lightboxIndex = (lightboxIndex - 1 + lightboxList.length) % lightboxList.length;
  document.getElementById("lightboxImg").src = lightboxList[lightboxIndex].image;
});
document.getElementById("lightboxNext").addEventListener("click", () => {
  lightboxIndex = (lightboxIndex + 1) % lightboxList.length;
  document.getElementById("lightboxImg").src = lightboxList[lightboxIndex].image;
});

/* ---------------------------------------------------------------------
   16. CARA ORDER (Timeline)
--------------------------------------------------------------------- */
function renderOrderTimeline() {
  document.getElementById("orderTimeline").innerHTML = ORDER_STEPS.map((step, i) => `
    <div class="timeline-step">
      <div class="num">${i + 1}</div>
      <i class="fa-solid ${step.icon}"></i>
      <p>${step.text}</p>
    </div>
  `).join("");
}

/* ---------------------------------------------------------------------
   17. CHECKOUT & PEMBAYARAN
--------------------------------------------------------------------- */
function renderPaymentMethods() {
  const pay = SITE_CONFIG.payment;
  document.getElementById("paymentMethods").innerHTML = `
    <div class="payment-card">
      <span class="p-icon">💙</span>
      <div class="p-info"><strong>GoPay</strong><br>${pay.gopayNumber} a.n ${pay.ownerName}</div>
      <button class="copy-btn" data-copy="${pay.gopayNumber}">Salin</button>
    </div>
    <div class="payment-card">
      <span class="p-icon">🔵</span>
      <div class="p-info"><strong>DANA</strong><br>${pay.danaNumber} a.n ${pay.ownerName}</div>
      <button class="copy-btn" data-copy="${pay.danaNumber}">Salin</button>
    </div>
    <div class="payment-card qris-box" style="display:block;">
      <span class="p-icon">⚫ QRIS</span>
      <img src="${pay.qrisImage}" alt="QRIS Graphic Desain Aden" id="qrisInlineImg" onerror="this.onerror=null;this.src='data:image/svg+xml;utf8,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22300%22%3E%3Crect width=%22300%22 height=%22300%22 fill=%22%23ffffff%22/%3E%3Crect x=%2210%22 y=%2210%22 width=%22280%22 height=%22280%22 fill=%22none%22 stroke=%22%2300BFFF%22 stroke-width=%222%22 stroke-dasharray=%228 6%22/%3E%3Ctext x=%22150%22 y=%22138%22 font-family=%22Arial,sans-serif%22 font-size=%2216%22 fill=%22%231E40AF%22 text-anchor=%22middle%22%3E%F0%9F%93%B7 Gambar QRIS%3C/text%3E%3Ctext x=%22150%22 y=%22162%22 font-family=%22Arial,sans-serif%22 font-size=%2216%22 fill=%22%231E40AF%22 text-anchor=%22middle%22%3Ebelum diunggah%3C/text%3E%3Ctext x=%22150%22 y=%22190%22 font-family=%22Arial,sans-serif%22 font-size=%2211%22 fill=%22%23555555%22 text-anchor=%22middle%22%3ELogin Admin %E2%86%92 Kelola Pembayaran%3C/text%3E%3C/svg%3E'">
      <button class="copy-btn mt-20" id="zoomQrisBtn">🔍 Perbesar QRIS</button>
    </div>
  `;
  document.querySelectorAll("[data-copy]").forEach(btn => {
    btn.addEventListener("click", () => {
      navigator.clipboard?.writeText(btn.dataset.copy).then(() => showToast("Nomor disalin"));
    });
  });

  // Perbesar QRIS: klik gambar kecil ATAU tombol "Perbesar QRIS" akan membuka modal QR ukuran besar agar mudah discan
  const openQrisZoom = () => {
    document.getElementById("qrisZoomImg").src = document.getElementById("qrisInlineImg").src;
    document.getElementById("qrisZoomModal").classList.add("open");
  };
  document.getElementById("qrisInlineImg").addEventListener("click", openQrisZoom);
  document.getElementById("zoomQrisBtn").addEventListener("click", openQrisZoom);
}
document.getElementById("qrisZoomClose").addEventListener("click", closeAllModals);

function renderCheckoutSummary() {
  const selected = cart.filter(c => c.selected);
  const items = selected.map(c => {
    const p = ALL_PRODUCTS.find(x => x.id === c.id);
    return p ? { ...p, qty: c.qty } : null;
  }).filter(Boolean);

  document.getElementById("checkoutSummaryItems").innerHTML = items.map(p => `
    <div style="display:flex;justify-content:space-between;font-size:0.82rem;padding:6px 0;border-bottom:1px solid rgba(0,0,0,0.06);">
      <span>${p.name} x${p.qty}</span><span>${formatRupiah(p.price * p.qty)}</span>
    </div>
  `).join("") || `<p class="empty-state">Belum ada produk dipilih.</p>`;

  const total = items.reduce((sum, p) => sum + p.price * p.qty, 0);
  document.getElementById("checkoutGrandTotal").textContent = formatRupiah(total);
  window._checkoutItems = items;
  window._checkoutTotal = total;
}

document.getElementById("submitConfirmBtn").addEventListener("click", () => {
  const name = document.getElementById("checkoutName").value.trim();
  const wa = document.getElementById("checkoutWa").value.trim();
  if (!name || !wa) {
    showToast("Lengkapi nama dan nomor WhatsApp dahulu", "fa-triangle-exclamation");
    return;
  }
  // simpan pesanan lokal untuk demo dashboard admin
  const order = {
    id: "ORD-" + Date.now(),
    name, wa,
    note: document.getElementById("checkoutNote").value.trim(),
    items: window._checkoutItems || [],
    total: window._checkoutTotal || 0,
    date: new Date().toISOString()
  };
  localOrders.push(order);
  Storage.set("gda_orders", localOrders);

  showToast("Konfirmasi tersimpan, lanjutkan via WhatsApp");
  document.getElementById("waConfirmBtn").style.display = "flex";
  document.getElementById("waConfirmBtn").onclick = () => {
    const ringkasan = (window._checkoutItems || []).map(p => `- ${p.name} x${p.qty} (${formatRupiah(p.price * p.qty)})`).join("\n");
    const msg = `${SITE_CONFIG.waMessageConfirm}\n\nNama: ${name}\nCatatan: ${order.note || "-"}\n\nRingkasan Pesanan:\n${ringkasan}\n\nTotal: ${formatRupiah(order.total)}`;
    window.open(waLink(msg), "_blank");
  };

  // kosongkan item yang sudah di-checkout dari keranjang
  cart = cart.filter(c => !c.selected);
  saveCart();
});

/* ---------------------------------------------------------------------
   18. WHATSAPP FLOATING & HERO BUTTON
--------------------------------------------------------------------- */
function bindWaButtons() {
  const ids = ["heroWaBtn", "kontakWaBtn", "fabWaBtn"];
  ids.forEach(id => {
    const btn = document.getElementById(id);
    if (btn) btn.addEventListener("click", () => window.open(waLink(SITE_CONFIG.waMessageOrder), "_blank"));
  });
}

/* ---------------------------------------------------------------------
   19. DARK MODE
--------------------------------------------------------------------- */
document.getElementById("darkModeBtn").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  const icon = document.querySelector("#darkModeBtn i");
  icon.className = document.body.classList.contains("dark") ? "fa-solid fa-sun" : "fa-solid fa-moon";
  Storage.set("gda_dark", document.body.classList.contains("dark"));
});
if (Storage.get("gda_dark", false)) {
  document.body.classList.add("dark");
  document.querySelector("#darkModeBtn i").className = "fa-solid fa-sun";
}

/* ---------------------------------------------------------------------
   20. LOGIN ADMIN & DASHBOARD
--------------------------------------------------------------------- */
document.getElementById("loginSubmitBtn").addEventListener("click", () => {
  const u = document.getElementById("loginUsername").value.trim();
  const p = document.getElementById("loginPassword").value.trim();
  if (u === SITE_CONFIG.admin.username && p === SITE_CONFIG.admin.password) {
    Storage.set("gda_admin_logged_in", true);
    goToPage("dashboard");
    renderDashboard("produk");
  } else {
    document.getElementById("loginError").textContent = "Username atau password salah.";
  }
});

document.getElementById("logoutBtn").addEventListener("click", () => {
  Storage.set("gda_admin_logged_in", false);
  goToPage("login");
});

document.querySelectorAll(".dash-menu-btn[data-tab]").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".dash-menu-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    renderDashboard(btn.dataset.tab);
  });
});

/* --- Upload Produk dengan Foto Otomatis (Admin) -----------------------
   Fitur ini bekerja seperti komponen "Upload Produk" standalone:
   admin memilih foto → foto langsung dibaca lewat FileReader (base64)
   → produk otomatis muncul di katalog tanpa perlu edit products.json.
   Produk tersimpan permanen di LocalStorage browser admin ini.
------------------------------------------------------------------------ */
function productUploadFormHtml() {
  const catOptions = CATEGORIES.map(c => `<option value="${c.id}">${c.label}</option>`).join("");
  return `
    <div class="about-box" style="text-align:left;max-width:460px;margin:0 0 34px;padding:26px;">
      <h3 style="margin-bottom:14px;"><i class="fa-solid fa-upload"></i> Upload Produk Baru</h3>

      <div class="form-group">
        <label>Foto Produk</label>
        <input type="file" id="dashImageInput" accept="image/*">
      </div>
      <div class="form-group">
        <label>Nama Produk</label>
        <input type="text" id="dashNamaInput" placeholder="Contoh: Netflix Premium 1 Bulan">
      </div>
      <div class="form-group">
        <label>Kategori</label>
        <select id="dashKategoriInput">${catOptions}</select>
      </div>
      <div class="form-group">
        <label>Keterangan Produk</label>
        <textarea id="dashDeskripsiInput" rows="3" placeholder="Deskripsi singkat produk"></textarea>
      </div>
      <div class="form-group">
        <label>Harga (Rp)</label>
        <input type="number" id="dashHargaInput" placeholder="Contoh: 25000">
      </div>

      <button class="btn btn-primary" id="dashUploadBtn" style="width:100%;justify-content:center;">
        <i class="fa-solid fa-upload"></i> Upload Produk
      </button>

      <!-- Preview otomatis setelah foto diproses -->
      <div id="dashUploadPreview" style="margin-top:16px;"></div>
    </div>
  `;
}

function bindDashUploadForm() {
  const btn = document.getElementById("dashUploadBtn");
  if (!btn) return;

  btn.addEventListener("click", () => {
    const fileInput = document.getElementById("dashImageInput");
    const nama = document.getElementById("dashNamaInput").value.trim();
    const kategori = document.getElementById("dashKategoriInput").value;
    const deskripsi = document.getElementById("dashDeskripsiInput").value.trim();
    const harga = document.getElementById("dashHargaInput").value;
    const file = fileInput.files[0];

    if (!file) { showToast("Pilih foto produk dulu!", "fa-triangle-exclamation"); return; }
    if (!nama || !harga) { showToast("Lengkapi nama dan harga produk", "fa-triangle-exclamation"); return; }

    // Baca file gambar dan ubah otomatis menjadi base64 (persis seperti contoh kode)
    const reader = new FileReader();
    reader.onload = function (e) {
      const newProduct = {
        id: "custom-" + Date.now(),
        name: nama,
        category: kategori,
        price: Number(harga),
        image: e.target.result, // foto otomatis tersimpan & tampil, tanpa upload ke server
        description: deskripsi || "Produk premium dari Graphic Desain Aden.",
        rating: 5,
        bestSeller: false,
        isNew: true,
        promo: false
      };

      // simpan permanen di LocalStorage supaya tetap ada setelah halaman di-refresh
      const customProducts = Storage.get("gda_custom_products", []);
      customProducts.push(newProduct);
      Storage.set("gda_custom_products", customProducts);

      // langsung tampilkan di katalog & home tanpa perlu reload halaman
      ALL_PRODUCTS.push(newProduct);
      renderHomeGrids();
      renderCatalog();

      // tampilkan preview produk yang baru saja diupload
      document.getElementById("dashUploadPreview").innerHTML = `
        <p style="font-size:0.78rem;color:var(--text-muted);margin-bottom:8px;">✅ Produk berhasil diupload dan otomatis tampil di katalog:</p>
        <div class="card" style="max-width:200px;">
          <div class="card-img-wrap"><img src="${newProduct.image}" alt="${newProduct.name}"></div>
          <div class="card-body">
            <span class="card-cat">${categoryLabel(newProduct.category)}</span>
            <span class="card-title">${newProduct.name}</span>
            <span class="card-price">${formatRupiah(newProduct.price)}</span>
          </div>
        </div>
      `;
      showToast("Produk berhasil diupload!", "fa-circle-check");
      renderDashboard("produk"); // refresh tabel daftar produk
    };
    reader.readAsDataURL(file);
  });
}

/* --- Hapus & Edit produk (berlaku untuk SEMUA produk, termasuk yang
   berasal dari products.json, bukan hanya hasil upload admin) --------
   Karena website statis, perubahan (edit teks/foto/hapus) disimpan di
   LocalStorage browser admin ini dan diterapkan otomatis di atas data
   products.json setiap kali website dibuka. Untuk perubahan permanen
   yang berlaku di semua pengunjung, sesuaikan juga file products.json.
------------------------------------------------------------------------ */
function applyProductOverrides() {
  const overrides = Storage.get("gda_product_overrides", {});
  ALL_PRODUCTS.forEach(p => {
    if (overrides[p.id]) Object.assign(p, overrides[p.id]);
  });
}

function saveProductOverride(id, fields) {
  const overrides = Storage.get("gda_product_overrides", {});
  overrides[id] = { ...(overrides[id] || {}), ...fields };
  Storage.set("gda_product_overrides", overrides);
}

document.addEventListener("click", (e) => {
  const delBtn = e.target.closest("[data-delprod]");
  if (delBtn) {
    const id = delBtn.dataset.delprod;
    if (!confirm("Yakin ingin menghapus produk ini dari menu jualan?")) return;

    ALL_PRODUCTS = ALL_PRODUCTS.filter(p => p.id !== id);

    // kalau produk ini hasil upload admin, hapus juga dari daftar custom
    const customProducts = Storage.get("gda_custom_products", []).filter(p => p.id !== id);
    Storage.set("gda_custom_products", customProducts);

    // catat sebagai "dihapus" supaya tidak muncul lagi walau berasal dari products.json
    const deletedIds = Storage.get("gda_deleted_products", []);
    if (!deletedIds.includes(id)) deletedIds.push(id);
    Storage.set("gda_deleted_products", deletedIds);

    renderHomeGrids();
    renderCatalog();
    renderDashboard("produk");
    showToast("Produk dihapus dari menu jualan", "fa-trash");
    return;
  }

  // tombol "Ganti Foto" (cepat, langsung dari tabel) — memicu klik ke input file tersembunyi
  const editImgBtn = e.target.closest("[data-editimg]");
  if (editImgBtn) {
    const input = document.getElementById("rowimg-" + editImgBtn.dataset.editimg);
    if (input) input.click();
    return;
  }

  // tombol "Edit" (lengkap) — buka modal edit semua teks & foto produk
  const editBtn = e.target.closest("[data-editprod]");
  if (editBtn) {
    openEditProductModal(editBtn.dataset.editprod);
    return;
  }
});

/* saat admin memilih file baru lewat tombol "Ganti Foto" cepat di tabel */
document.addEventListener("change", (e) => {
  const input = e.target.closest("[data-rowimg-input]");
  if (!input) return;
  const id = input.dataset.rowimgInput;
  const file = input.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function (e2) {
    const newImage = e2.target.result;
    const product = ALL_PRODUCTS.find(p => p.id === id);
    if (product) product.image = newImage;
    saveProductOverride(id, { image: newImage });

    renderHomeGrids();
    renderCatalog();
    renderDashboard("produk");
    showToast("Foto produk berhasil diganti", "fa-image");
  };
  reader.readAsDataURL(file);
});

/* ---------------------------------------------------------------------
   EDIT PRODUK LENGKAP (Modal) — admin bisa ubah nama, kategori, deskripsi,
   harga, rating, badge (Best Seller/Baru/Promo), dan foto sekaligus dalam
   satu tempat, untuk kemudahan mengedit halaman detail produk.
--------------------------------------------------------------------- */
function openEditProductModal(id) {
  const p = ALL_PRODUCTS.find(x => x.id === id);
  if (!p) return;
  const modal = document.getElementById("editProductModal");
  const box = document.getElementById("editProductModalBox");
  const catOptions = CATEGORIES.map(c => `<option value="${c.id}" ${c.id === p.category ? "selected" : ""}>${c.label}</option>`).join("");
  const ratingOptions = [5,4,3,2,1].map(r => `<option value="${r}" ${r === (p.rating||5) ? "selected" : ""}>${"★".repeat(r)}</option>`).join("");

  box.innerHTML = `
    <button class="modal-close" id="editModalCloseBtn"><i class="fa-solid fa-xmark"></i></button>
    <div class="product-detail-body">
      <h2 style="margin-bottom:16px;"><i class="fa-solid fa-pen"></i> Edit Produk</h2>

      <div class="form-group">
        <label>Foto Produk</label>
        <img src="${p.image}" alt="${p.name}" id="editPreviewImg" style="width:100%;max-width:220px;border-radius:12px;margin-bottom:8px;display:block;">
        <input type="file" id="editImageInput" accept="image/*">
      </div>
      <div class="form-group">
        <label>Nama Produk</label>
        <input type="text" id="editNamaInput" value="${p.name.replace(/"/g,'&quot;')}">
      </div>
      <div class="form-group">
        <label>Kategori</label>
        <select id="editKategoriInput">${catOptions}</select>
      </div>
      <div class="form-group">
        <label>Deskripsi / Detail Produk</label>
        <textarea id="editDeskripsiInput" rows="4">${p.description || ""}</textarea>
      </div>
      <div class="form-group">
        <label>Harga (Rp)</label>
        <input type="number" id="editHargaInput" value="${p.price}">
      </div>
      <div class="form-group">
        <label>Rating</label>
        <select id="editRatingInput">${ratingOptions}</select>
      </div>
      <div class="form-group">
        <label style="display:flex;align-items:center;gap:8px;font-weight:500;"><input type="checkbox" id="editBestSellerInput" ${p.bestSeller ? "checked" : ""}> 🔥 Tandai sebagai Best Seller</label>
        <label style="display:flex;align-items:center;gap:8px;font-weight:500;margin-top:6px;"><input type="checkbox" id="editIsNewInput" ${p.isNew ? "checked" : ""}> 🆕 Tandai sebagai Produk Baru</label>
        <label style="display:flex;align-items:center;gap:8px;font-weight:500;margin-top:6px;"><input type="checkbox" id="editPromoInput" ${p.promo ? "checked" : ""}> 💰 Tandai sebagai Promo</label>
      </div>

      <div class="detail-actions">
        <button class="btn btn-primary" id="editSaveBtn"><i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan</button>
        <button class="btn btn-outline" style="background:rgba(2,136,209,0.12);color:var(--primary-dark);" id="editCancelBtn">Batal</button>
      </div>
    </div>
  `;

  // preview foto baru secara instan saat file dipilih (belum tersimpan sebelum klik Simpan)
  let pendingImage = null;
  box.querySelector("#editImageInput").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e2) => {
      pendingImage = e2.target.result;
      box.querySelector("#editPreviewImg").src = pendingImage;
    };
    reader.readAsDataURL(file);
  });

  box.querySelector("#editModalCloseBtn").addEventListener("click", closeAllModals);
  box.querySelector("#editCancelBtn").addEventListener("click", closeAllModals);

  box.querySelector("#editSaveBtn").addEventListener("click", () => {
    const nama = box.querySelector("#editNamaInput").value.trim();
    const harga = Number(box.querySelector("#editHargaInput").value);
    if (!nama || !harga) {
      showToast("Nama dan harga tidak boleh kosong", "fa-triangle-exclamation");
      return;
    }

    const updatedFields = {
      name: nama,
      category: box.querySelector("#editKategoriInput").value,
      description: box.querySelector("#editDeskripsiInput").value.trim(),
      price: harga,
      rating: Number(box.querySelector("#editRatingInput").value),
      bestSeller: box.querySelector("#editBestSellerInput").checked,
      isNew: box.querySelector("#editIsNewInput").checked,
      promo: box.querySelector("#editPromoInput").checked
    };
    if (pendingImage) updatedFields.image = pendingImage;

    Object.assign(p, updatedFields);
    saveProductOverride(id, updatedFields);

    closeAllModals();
    renderHomeGrids();
    renderCatalog();
    renderDashboard("produk");
    showToast("Perubahan produk berhasil disimpan", "fa-circle-check");
  });

  modal.classList.add("open");
}

/* ---------------------------------------------------------------------
   21b. BROADCAST KATALOG — admin bisa "menembakkan" katalog produk
        (per kategori atau semua) sebagai pesan WhatsApp siap kirim,
        untuk broadcast ke grup, kontak, status, atau channel.
--------------------------------------------------------------------- */
function buildCatalogMessage(categoryId, header, footer) {
  const list = categoryId === "all" ? ALL_PRODUCTS : ALL_PRODUCTS.filter(p => p.category === categoryId);
  if (!list.length) return null;

  const catTitle = categoryId === "all" ? "Semua Produk" : categoryLabel(categoryId);
  const lines = list.map((p, i) => {
    const tags = [p.bestSeller ? "⭐ Best Seller" : "", p.promo ? "🔥 Promo" : ""].filter(Boolean).join(" ");
    return `${i + 1}. *${p.name}*\n   💰 ${formatRupiah(p.price)}${tags ? "\n   " + tags : ""}`;
  }).join("\n\n");

  const parts = [
    header && header.trim(),
    `📂 *Kategori: ${catTitle}*`,
    lines,
    footer && footer.trim()
  ].filter(Boolean);

  return parts.join("\n\n");
}

function renderBroadcastTab(content) {
  const catOptions = `<option value="all">🗂️ Semua Kategori</option>` +
    CATEGORIES.map(c => `<option value="${c.id}">${c.label}</option>`).join("");

  const defaultHeader = `Halo kak! 👋 Berikut update katalog terbaru dari *${SITE_CONFIG.siteName}* ✨`;
  const defaultFooter = `Untuk pemesanan / tanya-tanya langsung chat admin ya kak 🙏\n📱 ${SITE_CONFIG.whatsappNumber ? "wa.me/" + SITE_CONFIG.whatsappNumber : ""}`;

  content.innerHTML = `
    <h2 class="section-title">Broadcast Katalog</h2>
    <p class="section-sub">Pilih kategori produk (misalnya <strong>All Murid</strong> atau <strong>Poster Desain</strong>), lalu tembakkan katalognya sebagai pesan WhatsApp siap kirim ke grup, kontak, status, atau channel kamu.</p>

    <div class="dash-form" style="max-width:640px;">
      <div class="form-group">
        <label>Pilih Kategori</label>
        <select id="bcKategori">${catOptions}</select>
      </div>
      <div class="form-group">
        <label>Kalimat Pembuka</label>
        <textarea id="bcHeader" rows="2">${defaultHeader}</textarea>
      </div>
      <div class="form-group">
        <label>Kalimat Penutup / CTA</label>
        <textarea id="bcFooter" rows="2">${defaultFooter}</textarea>
      </div>
      <button class="btn btn-primary" id="bcGenerateBtn" style="width:100%;justify-content:center;"><i class="fa-solid fa-arrows-rotate"></i> Buat Pesan Katalog</button>
    </div>

    <div class="dash-form" style="max-width:640px;margin-top:20px;">
      <div class="form-group">
        <label>Preview Pesan (bisa diedit sebelum dikirim)</label>
        <textarea id="bcPreview" rows="12" placeholder="Klik 'Buat Pesan Katalog' untuk membuat preview..."></textarea>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:10px;">
        <button class="btn btn-outline" id="bcCopyBtn" style="color:var(--primary);border-color:var(--primary);"><i class="fa-solid fa-copy"></i> Salin Pesan</button>
        <button class="btn btn-primary" id="bcSendBtn"><i class="fa-brands fa-whatsapp"></i> Kirim / Broadcast via WhatsApp</button>
      </div>
      <p style="font-size:0.8rem;color:var(--text-muted);margin-top:10px;">
        Tombol "Kirim / Broadcast" akan membuka WhatsApp dengan pesan sudah terisi — kamu tinggal pilih kontak, grup, daftar broadcast, atau Status untuk mengirimkannya.
      </p>
    </div>
  `;

  const regenerate = () => {
    const cat = document.getElementById("bcKategori").value;
    const header = document.getElementById("bcHeader").value;
    const footer = document.getElementById("bcFooter").value;
    const msg = buildCatalogMessage(cat, header, footer);
    const preview = document.getElementById("bcPreview");
    if (!msg) {
      preview.value = "";
      showToast("Belum ada produk di kategori ini", "fa-triangle-exclamation");
      return;
    }
    preview.value = msg;
  };

  document.getElementById("bcGenerateBtn").addEventListener("click", regenerate);

  document.getElementById("bcCopyBtn").addEventListener("click", () => {
    const text = document.getElementById("bcPreview").value;
    if (!text.trim()) { showToast("Buat pesan katalog dahulu", "fa-triangle-exclamation"); return; }
    navigator.clipboard?.writeText(text).then(() => showToast("Pesan katalog disalin", "fa-copy"));
  });

  document.getElementById("bcSendBtn").addEventListener("click", () => {
    const text = document.getElementById("bcPreview").value;
    if (!text.trim()) { showToast("Buat pesan katalog dahulu", "fa-triangle-exclamation"); return; }
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, "_blank");
  });

  // Buat preview otomatis begitu tab dibuka
  regenerate();
}

function renderDashboard(tab) {
  document.getElementById("dashAdminName").textContent = SITE_CONFIG.admin.name;
  const content = document.getElementById("dashContent");

  if (tab === "produk") {
    content.innerHTML = `
      <h2 class="section-title">Kelola Produk</h2>
      <p class="section-sub">Total ${ALL_PRODUCTS.length} produk. Tambah produk baru lewat form di bawah, atau klik <strong>Edit</strong> pada tabel untuk mengubah nama, deskripsi, harga, kategori, dan foto produk mana pun dengan cepat.</p>

      ${productUploadFormHtml()}

      <table class="dash-table">
        <thead><tr><th>Foto</th><th>Nama</th><th>Kategori</th><th>Harga</th><th>Best Seller</th><th>Promo</th><th>Aksi</th></tr></thead>
        <tbody>
          ${ALL_PRODUCTS.map(p => `
            <tr>
              <td><img src="${p.image}" alt="${p.name}" style="width:42px;height:42px;object-fit:cover;border-radius:8px;"></td>
              <td>${p.name}</td><td>${categoryLabel(p.category)}</td><td>${formatRupiah(p.price)}</td>
              <td>${p.bestSeller ? "✅" : "—"}</td><td>${p.promo ? "✅" : "—"}</td>
              <td style="white-space:nowrap;">
                <input type="file" accept="image/*" id="rowimg-${p.id}" data-rowimg-input="${p.id}" class="hidden">
                <button class="copy-btn" data-editprod="${p.id}"><i class="fa-solid fa-pen"></i> Edit</button>
                <button class="copy-btn" data-editimg="${p.id}"><i class="fa-solid fa-image"></i> Ganti Foto</button>
                <button class="copy-btn" data-delprod="${p.id}" style="color:#ef476f;"><i class="fa-solid fa-trash"></i> Hapus</button>
              </td>
            </tr>`).join("")}
        </tbody>
      </table>
    `;
    bindDashUploadForm();
  } else if (tab === "banner") {
    content.innerHTML = `
      <h2 class="section-title">Kelola Banner</h2>
      <p class="section-sub">Tambah, ganti, atau hapus gambar Hero Banner. Perubahan langsung tersimpan dan tampil di halaman utama.</p>

      <div class="about-box" style="text-align:left;max-width:460px;margin:0 0 26px;padding:22px;">
        <h3 style="margin-bottom:14px;"><i class="fa-solid fa-plus"></i> Tambah Banner Baru</h3>
        <div class="form-group"><label>Gambar Banner</label><input type="file" id="addBannerInput" accept="image/*"></div>
        <button class="btn btn-primary" id="addBannerBtn" style="width:100%;justify-content:center;"><i class="fa-solid fa-upload"></i> Tambah Banner</button>
      </div>

      <div class="product-grid">
        ${BANNERS.map((b,i) => `
          <div class="card">
            <div class="card-img-wrap"><img src="${b.image}"></div>
            <div class="card-body">
              Banner ${i+1}
              <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap;">
                <input type="file" accept="image/*" id="bannerimg-${b.id}" data-bannerimg-input="${b.id}" class="hidden">
                <button class="copy-btn" data-editbanner="${b.id}"><i class="fa-solid fa-image"></i> Ganti</button>
                <button class="copy-btn" data-delbanner="${b.id}" style="color:#ef476f;"><i class="fa-solid fa-trash"></i> Hapus</button>
              </div>
            </div>
          </div>`).join("")}
      </div>
    `;
    bindBannerDashHandlers();
  } else if (tab === "galeri") {
    const catOptions = ["Logo Guild","Poster","Skin Guild","Banner","Thumbnail","Hosting","Akun Game"].map(c => `<option value="${c}">${c}</option>`).join("");
    content.innerHTML = `
      <h2 class="section-title">Kelola Galeri</h2>
      <p class="section-sub">Total ${GALLERY_ITEMS.length} item galeri. Tambah, ganti foto, atau hapus item galeri di bawah ini.</p>

      <div class="about-box" style="text-align:left;max-width:460px;margin:0 0 26px;padding:22px;">
        <h3 style="margin-bottom:14px;"><i class="fa-solid fa-plus"></i> Tambah Item Galeri</h3>
        <div class="form-group"><label>Gambar</label><input type="file" id="addGaleriInput" accept="image/*"></div>
        <div class="form-group"><label>Kategori</label><select id="addGaleriKategori">${catOptions}</select></div>
        <button class="btn btn-primary" id="addGaleriBtn" style="width:100%;justify-content:center;"><i class="fa-solid fa-upload"></i> Tambah ke Galeri</button>
      </div>

      <div class="masonry">
        ${GALLERY_ITEMS.map(g => `
          <div class="masonry-item">
            <img src="${g.image}">
            <div class="m-label">${g.category}</div>
            <div style="display:flex;gap:6px;padding:8px;background:rgba(0,0,0,0.55);">
              <input type="file" accept="image/*" id="galimg-${g.id}" data-galimg-input="${g.id}" class="hidden">
              <button class="copy-btn" data-editgaleri="${g.id}"><i class="fa-solid fa-image"></i></button>
              <button class="copy-btn" data-delgaleri="${g.id}" style="color:#ef476f;"><i class="fa-solid fa-trash"></i></button>
            </div>
          </div>`).join("")}
      </div>
    `;
    bindGaleriDashHandlers();
  } else if (tab === "testimoni") {
    content.innerHTML = `
      <h2 class="section-title">Kelola Testimoni</h2>
      <p class="section-sub">Tambah, edit, atau hapus testimoni pelanggan yang tampil di website.</p>

      <div class="about-box" style="text-align:left;max-width:460px;margin:0 0 26px;padding:22px;">
        <h3 style="margin-bottom:14px;"><i class="fa-solid fa-plus"></i> Tambah Testimoni</h3>
        <div class="form-group"><label>Nama Pelanggan</label><input type="text" id="addTestiNama" placeholder="Contoh: Budi S."></div>
        <div class="form-group"><label>Foto Pelanggan</label><input type="file" id="addTestiFoto" accept="image/*"></div>
        <div class="form-group"><label>Foto Hasil Desain</label><input type="file" id="addTestiHasil" accept="image/*"></div>
        <div class="form-group"><label>Komentar</label><textarea id="addTestiKomentar" rows="3" placeholder="Komentar pelanggan"></textarea></div>
        <div class="form-group"><label>Rating</label>
          <select id="addTestiRating">${[5,4,3,2,1].map(r => `<option value="${r}">${"★".repeat(r)}</option>`).join("")}</select>
        </div>
        <button class="btn btn-primary" id="addTestiBtn" style="width:100%;justify-content:center;"><i class="fa-solid fa-upload"></i> Tambah Testimoni</button>
      </div>

      <table class="dash-table">
        <thead><tr><th>Foto</th><th>Nama</th><th>Komentar</th><th>Rating</th><th>Aksi</th></tr></thead>
        <tbody>${TESTIMONIALS.map(t => `
          <tr>
            <td><img src="${t.photo}" style="width:36px;height:36px;object-fit:cover;border-radius:50%;"></td>
            <td>${t.name}</td><td style="max-width:220px;">${t.comment}</td><td>${starIcons(t.rating)}</td>
            <td style="white-space:nowrap;">
              <button class="copy-btn" data-edittesti="${t.id}"><i class="fa-solid fa-pen"></i> Edit</button>
              <button class="copy-btn" data-deltesti="${t.id}" style="color:#ef476f;"><i class="fa-solid fa-trash"></i> Hapus</button>
            </td>
          </tr>`).join("")}</tbody>
      </table>
    `;
    bindTestiDashHandlers();
  } else if (tab === "konten") {
    const t = getPageText();
    content.innerHTML = `
      <h2 class="section-title">Teks Halaman</h2>
      <p class="section-sub">Ubah judul Hero Banner, subjudul, teks "Tentang Kami", teks halaman Sewa Desain, dan teks detail produk (estimasi, revisi, bonus).</p>
      <div class="dash-form">
        <div class="form-group"><label>Judul Hero</label><input type="text" id="pengJudulHero" value="${t.heroTitle.replace(/"/g,'&quot;')}"></div>
        <div class="form-group"><label>Subjudul Hero</label><textarea id="pengSubjudulHero" rows="3">${t.heroSubtitle}</textarea></div>
        <div class="form-group"><label>Teks Tentang Kami</label><textarea id="pengAboutText" rows="5">${t.aboutText}</textarea></div>

        <h3 style="margin:22px 0 4px;"><i class="fa-solid fa-calendar-days"></i> Halaman Sewa Desain / Paket Harga</h3>
        <div class="form-group"><label>Judul Halaman Sewa Desain</label><input type="text" id="pengSewaTitle" value="${t.sewaTitle.replace(/"/g,'&quot;')}"></div>
        <div class="form-group"><label>Sub Judul Halaman Sewa Desain</label><textarea id="pengSewaSub" rows="2">${t.sewaSubtitle}</textarea></div>
        <p class="section-sub" style="margin-top:-6px;">Untuk mengubah nama paket, harga, badge, dan fitur tiap paket, buka menu <strong>Kelola Sewa &amp; Paket Harga</strong> di sidebar.</p>

        <h3 style="margin:22px 0 4px;"><i class="fa-solid fa-file-lines"></i> Detail Produk</h3>
        <div class="form-group"><label>Estimasi Pengerjaan</label><input type="text" id="pengEstimasi" value="${t.estimasiPengerjaan.replace(/"/g,'&quot;')}"></div>
        <div class="form-group"><label>Teks Revisi</label><input type="text" id="pengRevisi" value="${t.revisiText.replace(/"/g,'&quot;')}"></div>
        <div class="form-group"><label>Teks Bonus</label><input type="text" id="pengBonus" value="${t.bonusText.replace(/"/g,'&quot;')}"></div>

        <button class="btn btn-primary" id="saveKontenBtn"><i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan</button>
      </div>
    `;
    document.getElementById("saveKontenBtn").addEventListener("click", () => {
      savePageText({
        heroTitle: document.getElementById("pengJudulHero").value.trim() || DEFAULT_PAGE_TEXT.heroTitle,
        heroSubtitle: document.getElementById("pengSubjudulHero").value.trim() || DEFAULT_PAGE_TEXT.heroSubtitle,
        aboutText: document.getElementById("pengAboutText").value.trim() || DEFAULT_PAGE_TEXT.aboutText,
        sewaTitle: document.getElementById("pengSewaTitle").value.trim() || DEFAULT_PAGE_TEXT.sewaTitle,
        sewaSubtitle: document.getElementById("pengSewaSub").value.trim() || DEFAULT_PAGE_TEXT.sewaSubtitle,
        estimasiPengerjaan: document.getElementById("pengEstimasi").value.trim() || DEFAULT_PAGE_TEXT.estimasiPengerjaan,
        revisiText: document.getElementById("pengRevisi").value.trim() || DEFAULT_PAGE_TEXT.revisiText,
        bonusText: document.getElementById("pengBonus").value.trim() || DEFAULT_PAGE_TEXT.bonusText
      });
      showToast("Teks halaman berhasil disimpan", "fa-circle-check");
    });
  } else if (tab === "sewa") {
    content.innerHTML = `
      <h2 class="section-title">Kelola Sewa Desain &amp; Paket Harga</h2>
      <p class="section-sub">Tambah, edit, atau hapus paket sewa desain yang tampil di halaman "Sewa Desain / Paket Harga". Total ${PACKAGES.length} paket aktif.</p>

      <div class="about-box" style="text-align:left;max-width:520px;margin:0 0 26px;padding:22px;">
        <h3 style="margin-bottom:14px;"><i class="fa-solid fa-plus"></i> Tambah Paket Baru</h3>
        <div class="form-group"><label>Nama Paket</label><input type="text" id="addPkgNama" placeholder="Contoh: Paket 6 Bulan"></div>
        <div class="form-group"><label>Harga (Rp)</label><input type="number" id="addPkgHarga" placeholder="Contoh: 2200000"></div>
        <div class="form-group"><label>Label Badge (opsional)</label><input type="text" id="addPkgBadge" placeholder="Contoh: 🔥 Best Value"></div>
        <div class="form-group"><label>Daftar Fitur (satu baris = satu fitur)</label><textarea id="addPkgFitur" rows="4" placeholder="Unlimited Request&#10;Unlimited Revisi&#10;Bonus Banner"></textarea></div>
        <div class="form-group"><label><input type="checkbox" id="addPkgPopuler" style="width:auto;"> Tandai sebagai paket populer</label></div>
        <button class="btn btn-primary" id="addPkgBtn" style="width:100%;justify-content:center;"><i class="fa-solid fa-plus"></i> Tambah Paket</button>
      </div>

      <table class="dash-table">
        <thead><tr><th>Paket</th><th>Harga</th><th>Badge</th><th>Populer</th><th>Fitur</th><th>Aksi</th></tr></thead>
        <tbody>${PACKAGES.map(pkg => `
          <tr>
            <td>${pkg.name}</td>
            <td>${formatRupiah(pkg.price)}</td>
            <td>${pkg.badge || "-"}</td>
            <td>${pkg.popular ? "✅" : "-"}</td>
            <td style="max-width:220px;font-size:0.75rem;">${pkg.features.join(", ")}</td>
            <td style="white-space:nowrap;">
              <button class="copy-btn" data-editpkg="${pkg.id}"><i class="fa-solid fa-pen"></i> Edit</button>
              <button class="copy-btn" data-delpkg="${pkg.id}" style="color:#ef476f;"><i class="fa-solid fa-trash"></i> Hapus</button>
            </td>
          </tr>`).join("")}</tbody>
      </table>
      <button class="copy-btn mt-20" id="resetPkgBtn" style="color:#ef476f;"><i class="fa-solid fa-rotate-left"></i> Kembalikan ke Paket Default</button>
    `;
    bindPackageDashHandlers();
  } else if (tab === "pembayaran") {
    const pay = SITE_CONFIG.payment;
    content.innerHTML = `
      <h2 class="section-title">Kelola Pembayaran</h2>
      <p class="section-sub">Ubah nomor GoPay, DANA, nama pemilik rekening, dan gambar QRIS yang tampil di halaman checkout.</p>

      <div class="qris-upload-box" id="qrisUploadBox">
        <div class="qris-upload-preview">
          <img src="${pay.qrisImage}" id="payQrisPreview" alt="QRIS" onerror="this.style.display='none'">
        </div>
        <div class="qris-upload-overlay" id="qrisUploadOverlay">
          <i class="fa-solid fa-camera"></i>
          <span>Klik atau seret gambar QRIS ke sini untuk mengganti</span>
          <small>Tersimpan otomatis begitu gambar dipilih</small>
        </div>
        <input type="file" id="payQrisInput" accept="image/*" class="hidden">
      </div>

      <div class="dash-form" style="margin-top:22px;">
        <div class="form-group"><label>Nomor GoPay</label><input type="text" id="payGopay" value="${pay.gopayNumber}"></div>
        <div class="form-group"><label>Nomor DANA</label><input type="text" id="payDana" value="${pay.danaNumber}"></div>
        <div class="form-group"><label>Nama Pemilik</label><input type="text" id="payNama" value="${pay.ownerName}"></div>
        <button class="btn btn-primary" id="savePaymentBtn"><i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan</button>
      </div>
    `;

    const qrisBox = document.getElementById("qrisUploadBox");
    const qrisInput = document.getElementById("payQrisInput");
    const qrisPreview = document.getElementById("payQrisPreview");

    const applyQrisFile = (file) => {
      if (!file || !file.type.startsWith("image/")) {
        showToast("File harus berupa gambar", "fa-triangle-exclamation");
        return;
      }
      const reader = new FileReader();
      reader.onload = (e) => {
        qrisPreview.src = e.target.result;
        qrisPreview.style.display = "block";
        saveSiteOverride({ payment: { qrisImage: e.target.result } });
        renderPaymentMethods();
        showToast("QRIS berhasil diperbarui", "fa-circle-check");
      };
      reader.readAsDataURL(file);
    };

    // Klik kotak QRIS mana pun langsung buka pemilih file
    qrisBox.addEventListener("click", () => qrisInput.click());
    qrisInput.addEventListener("change", (e) => applyQrisFile(e.target.files[0]));

    // Dukungan drag & drop gambar QRIS
    ["dragover", "dragenter"].forEach(evt => {
      qrisBox.addEventListener(evt, (e) => { e.preventDefault(); qrisBox.classList.add("drag-active"); });
    });
    ["dragleave", "dragend"].forEach(evt => {
      qrisBox.addEventListener(evt, () => qrisBox.classList.remove("drag-active"));
    });
    qrisBox.addEventListener("drop", (e) => {
      e.preventDefault();
      qrisBox.classList.remove("drag-active");
      const file = e.dataTransfer.files && e.dataTransfer.files[0];
      applyQrisFile(file);
    });

    document.getElementById("savePaymentBtn").addEventListener("click", () => {
      const fields = {
        payment: {
          gopayNumber: document.getElementById("payGopay").value.trim(),
          danaNumber: document.getElementById("payDana").value.trim(),
          ownerName: document.getElementById("payNama").value.trim()
        }
      };
      saveSiteOverride(fields);
      renderPaymentMethods();
      showToast("Pengaturan pembayaran disimpan", "fa-circle-check");
    });
  } else if (tab === "pesanan") {
    content.innerHTML = `
      <h2 class="section-title">Pesanan Lokal</h2>
      <p class="section-sub">Pesanan yang dikonfirmasi lewat Checkout tersimpan di sini (LocalStorage browser ini saja).</p>
      <table class="dash-table">
        <thead><tr><th>ID</th><th>Nama</th><th>WhatsApp</th><th>Total</th><th>Tanggal</th></tr></thead>
        <tbody>
          ${localOrders.length ? localOrders.map(o => `
            <tr><td>${o.id}</td><td>${o.name}</td><td>${o.wa}</td><td>${formatRupiah(o.total)}</td><td>${new Date(o.date).toLocaleString("id-ID")}</td></tr>
          `).join("") : `<tr><td colspan="5">Belum ada pesanan.</td></tr>`}
        </tbody>
      </table>
    `;
  } else if (tab === "broadcast") {
    renderBroadcastTab(content);
  } else if (tab === "pengaturan") {
    content.innerHTML = `
      <h2 class="section-title">Pengaturan Website</h2>
      <p class="section-sub">Ubah nama website, logo, kontak, dan sosial media yang tampil di seluruh halaman.</p>
      <div class="dash-form">
        <div class="form-group">
          <label>Logo Website</label>
          <img src="${SITE_CONFIG.logo && SITE_CONFIG.logo.startsWith("data:") ? SITE_CONFIG.logo : document.getElementById("navLogoImg").src}" id="pengLogoPreview" style="width:70px;height:70px;object-fit:cover;border-radius:50%;display:block;margin-bottom:8px;">
          <input type="file" id="pengLogoInput" accept="image/*">
        </div>
        <div class="form-group"><label>Nama Website</label><input type="text" id="pengSiteName" value="${SITE_CONFIG.siteName}"></div>
        <div class="form-group"><label>Tagline</label><input type="text" id="pengTagline" value="${SITE_CONFIG.siteTagline}"></div>
        <div class="form-group"><label>Nomor WhatsApp (format 62xxx)</label><input type="text" id="pengWa" value="${SITE_CONFIG.whatsappNumber}"></div>
        <div class="form-group"><label>Instagram</label><input type="text" id="pengIg" value="${SITE_CONFIG.instagram}"></div>
        <div class="form-group"><label>TikTok</label><input type="text" id="pengTiktok" value="${SITE_CONFIG.tiktok}"></div>
        <div class="form-group"><label>Facebook</label><input type="text" id="pengFb" value="${SITE_CONFIG.facebook}"></div>
        <div class="form-group"><label>YouTube</label><input type="text" id="pengYt" value="${SITE_CONFIG.youtube}"></div>
        <div class="form-group"><label>Teks Copyright</label><input type="text" id="pengCopyright" value="${SITE_CONFIG.copyrightText}"></div>
        <button class="btn btn-primary" id="saveSiteBtn"><i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan</button>
      </div>
    `;
    let pendingLogo = null;
    document.getElementById("pengLogoInput").addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (e2) => {
        pendingLogo = e2.target.result;
        document.getElementById("pengLogoPreview").src = pendingLogo;
      };
      reader.readAsDataURL(file);
    });
    document.getElementById("saveSiteBtn").addEventListener("click", () => {
      const fields = {
        siteName: document.getElementById("pengSiteName").value.trim(),
        siteTagline: document.getElementById("pengTagline").value.trim(),
        whatsappNumber: document.getElementById("pengWa").value.trim(),
        instagram: document.getElementById("pengIg").value.trim(),
        tiktok: document.getElementById("pengTiktok").value.trim(),
        facebook: document.getElementById("pengFb").value.trim(),
        youtube: document.getElementById("pengYt").value.trim(),
        copyrightText: document.getElementById("pengCopyright").value.trim()
      };
      if (pendingLogo) fields.logo = pendingLogo;
      saveSiteOverride(fields);
      applyConfig();
      showToast("Pengaturan website disimpan", "fa-circle-check");
    });
  } else if (tab === "statistik") {
    content.innerHTML = `
      <h2 class="section-title">Statistik</h2>
      <div class="dash-stats">
        <div class="stat-box"><div class="num">${ALL_PRODUCTS.length}</div><div class="label">Total Produk</div></div>
        <div class="stat-box"><div class="num">${localOrders.length}</div><div class="label">Pesanan Masuk</div></div>
        <div class="stat-box"><div class="num">${wishlist.length}</div><div class="label">Wishlist Aktif (browser ini)</div></div>
        <div class="stat-box"><div class="num">${TESTIMONIALS.length}</div><div class="label">Testimoni</div></div>
      </div>
    `;
  }
}

/* ---------------------------------------------------------------------
   22. HANDLER DASHBOARD: BANNER
--------------------------------------------------------------------- */
function bindBannerDashHandlers() {
  const addBtn = document.getElementById("addBannerBtn");
  if (addBtn) {
    addBtn.addEventListener("click", () => {
      const file = document.getElementById("addBannerInput").files[0];
      if (!file) { showToast("Pilih gambar banner dulu!", "fa-triangle-exclamation"); return; }
      const reader = new FileReader();
      reader.onload = (e) => {
        BANNERS.push({ id: "custom-" + Date.now(), image: e.target.result });
        saveBanners();
        renderHero();
        renderDashboard("banner");
        showToast("Banner berhasil ditambahkan", "fa-circle-check");
      };
      reader.readAsDataURL(file);
    });
  }

  document.querySelectorAll("[data-editbanner]").forEach(btn => {
    btn.addEventListener("click", () => {
      document.getElementById("bannerimg-" + btn.dataset.editbanner).click();
    });
  });
  document.querySelectorAll("[data-bannerimg-input]").forEach(input => {
    input.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const id = input.dataset.bannerimgInput;
      const reader = new FileReader();
      reader.onload = (e2) => {
        const b = BANNERS.find(x => x.id === id);
        if (b) b.image = e2.target.result;
        saveBanners();
        renderHero();
        renderDashboard("banner");
        showToast("Gambar banner berhasil diganti", "fa-image");
      };
      reader.readAsDataURL(file);
    });
  });
  document.querySelectorAll("[data-delbanner]").forEach(btn => {
    btn.addEventListener("click", () => {
      if (!confirm("Yakin ingin menghapus banner ini?")) return;
      BANNERS = BANNERS.filter(b => b.id !== btn.dataset.delbanner);
      saveBanners();
      renderHero();
      renderDashboard("banner");
      showToast("Banner dihapus", "fa-trash");
    });
  });
}

/* ---------------------------------------------------------------------
   23. HANDLER DASHBOARD: GALERI
--------------------------------------------------------------------- */
function bindGaleriDashHandlers() {
  const addBtn = document.getElementById("addGaleriBtn");
  if (addBtn) {
    addBtn.addEventListener("click", () => {
      const file = document.getElementById("addGaleriInput").files[0];
      const category = document.getElementById("addGaleriKategori").value;
      if (!file) { showToast("Pilih gambar galeri dulu!", "fa-triangle-exclamation"); return; }
      const reader = new FileReader();
      reader.onload = (e) => {
        const custom = Storage.get("gda_gallery_custom", []);
        custom.push({ id: "custom-" + Date.now(), category, image: e.target.result });
        saveGalleryCustom(custom);
        loadGallery();
        renderGalleryFilter();
        renderGalleryGrid();
        renderGalleryPreview();
        renderDashboard("galeri");
        showToast("Item galeri berhasil ditambahkan", "fa-circle-check");
      };
      reader.readAsDataURL(file);
    });
  }

  document.querySelectorAll("[data-editgaleri]").forEach(btn => {
    btn.addEventListener("click", () => {
      document.getElementById("galimg-" + btn.dataset.editgaleri).click();
    });
  });
  document.querySelectorAll("[data-galimg-input]").forEach(input => {
    input.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const id = input.dataset.galimgInput;
      const reader = new FileReader();
      reader.onload = (e2) => {
        if (id.startsWith("custom-")) {
          const custom = Storage.get("gda_gallery_custom", []);
          const item = custom.find(g => g.id === id);
          if (item) item.image = e2.target.result;
          saveGalleryCustom(custom);
        } else {
          saveGalleryOverride(id, { image: e2.target.result });
        }
        loadGallery();
        renderGalleryFilter();
        renderGalleryGrid();
        renderGalleryPreview();
        renderDashboard("galeri");
        showToast("Gambar galeri berhasil diganti", "fa-image");
      };
      reader.readAsDataURL(file);
    });
  });
  document.querySelectorAll("[data-delgaleri]").forEach(btn => {
    btn.addEventListener("click", () => {
      if (!confirm("Yakin ingin menghapus item galeri ini?")) return;
      deleteGalleryItem(btn.dataset.delgaleri);
      renderGalleryFilter();
      renderGalleryGrid();
      renderGalleryPreview();
      renderDashboard("galeri");
      showToast("Item galeri dihapus", "fa-trash");
    });
  });
}

/* ---------------------------------------------------------------------
   24. HANDLER DASHBOARD: TESTIMONI
--------------------------------------------------------------------- */
function bindTestiDashHandlers() {
  const addBtn = document.getElementById("addTestiBtn");
  if (addBtn) {
    addBtn.addEventListener("click", () => {
      const nama = document.getElementById("addTestiNama").value.trim();
      const komentar = document.getElementById("addTestiKomentar").value.trim();
      const rating = Number(document.getElementById("addTestiRating").value);
      const fotoFile = document.getElementById("addTestiFoto").files[0];
      const hasilFile = document.getElementById("addTestiHasil").files[0];
      if (!nama || !komentar) { showToast("Lengkapi nama dan komentar", "fa-triangle-exclamation"); return; }

      const readAsDataUrl = (file) => new Promise((resolve) => {
        if (!file) { resolve("https://picsum.photos/seed/" + Date.now() + "/400/240"); return; }
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.readAsDataURL(file);
      });

      Promise.all([readAsDataUrl(fotoFile), readAsDataUrl(hasilFile)]).then(([photo, result]) => {
        const custom = Storage.get("gda_testi_custom", []);
        custom.push({ id: "custom-" + Date.now(), name: nama, photo, result, comment: komentar, rating });
        saveTestiCustom(custom);
        loadTestimonials();
        renderTestimonials();
        renderDashboard("testimoni");
        showToast("Testimoni berhasil ditambahkan", "fa-circle-check");
      });
    });
  }

  document.querySelectorAll("[data-edittesti]").forEach(btn => {
    btn.addEventListener("click", () => openEditTestiModal(btn.dataset.edittesti));
  });
  document.querySelectorAll("[data-deltesti]").forEach(btn => {
    btn.addEventListener("click", () => {
      if (!confirm("Yakin ingin menghapus testimoni ini?")) return;
      deleteTestiItem(btn.dataset.deltesti);
      renderTestimonials();
      renderDashboard("testimoni");
      showToast("Testimoni dihapus", "fa-trash");
    });
  });
}

function openEditTestiModal(id) {
  const t = TESTIMONIALS.find(x => x.id === id);
  if (!t) return;
  const modal = document.getElementById("editProductModal");
  const box = document.getElementById("editProductModalBox");
  box.innerHTML = `
    <button class="modal-close" id="editTestiCloseBtn"><i class="fa-solid fa-xmark"></i></button>
    <div class="product-detail-body">
      <h2 style="margin-bottom:16px;"><i class="fa-solid fa-pen"></i> Edit Testimoni</h2>
      <div class="form-group">
        <label>Foto Pelanggan</label>
        <img src="${t.photo}" id="editTestiFotoPreview" style="width:70px;height:70px;object-fit:cover;border-radius:50%;display:block;margin-bottom:8px;">
        <input type="file" id="editTestiFotoInput" accept="image/*">
      </div>
      <div class="form-group">
        <label>Foto Hasil Desain</label>
        <img src="${t.result}" id="editTestiHasilPreview" style="width:100%;max-width:220px;border-radius:12px;display:block;margin-bottom:8px;">
        <input type="file" id="editTestiHasilInput" accept="image/*">
      </div>
      <div class="form-group"><label>Nama</label><input type="text" id="editTestiNama" value="${t.name.replace(/"/g,'&quot;')}"></div>
      <div class="form-group"><label>Komentar</label><textarea id="editTestiKomentar" rows="3">${t.comment}</textarea></div>
      <div class="form-group"><label>Rating</label>
        <select id="editTestiRating">${[5,4,3,2,1].map(r => `<option value="${r}" ${r === t.rating ? "selected" : ""}>${"★".repeat(r)}</option>`).join("")}</select>
      </div>
      <div class="detail-actions">
        <button class="btn btn-primary" id="editTestiSaveBtn"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
        <button class="btn btn-outline" style="background:rgba(2,136,209,0.12);color:var(--primary-dark);" id="editTestiCancelBtn">Batal</button>
      </div>
    </div>
  `;

  let pendingFoto = null, pendingHasil = null;
  box.querySelector("#editTestiFotoInput").addEventListener("change", (e) => {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = (e2) => { pendingFoto = e2.target.result; box.querySelector("#editTestiFotoPreview").src = pendingFoto; };
    reader.readAsDataURL(file);
  });
  box.querySelector("#editTestiHasilInput").addEventListener("change", (e) => {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = (e2) => { pendingHasil = e2.target.result; box.querySelector("#editTestiHasilPreview").src = pendingHasil; };
    reader.readAsDataURL(file);
  });

  box.querySelector("#editTestiCloseBtn").addEventListener("click", closeAllModals);
  box.querySelector("#editTestiCancelBtn").addEventListener("click", closeAllModals);
  box.querySelector("#editTestiSaveBtn").addEventListener("click", () => {
    const fields = {
      name: box.querySelector("#editTestiNama").value.trim(),
      comment: box.querySelector("#editTestiKomentar").value.trim(),
      rating: Number(box.querySelector("#editTestiRating").value)
    };
    if (pendingFoto) fields.photo = pendingFoto;
    if (pendingHasil) fields.result = pendingHasil;

    if (id.startsWith("custom-")) {
      const custom = Storage.get("gda_testi_custom", []);
      const item = custom.find(x => x.id === id);
      if (item) Object.assign(item, fields);
      saveTestiCustom(custom);
    } else {
      saveTestiOverride(id, fields);
    }
    loadTestimonials();
    renderTestimonials();
    closeAllModals();
    renderDashboard("testimoni");
    showToast("Testimoni berhasil diperbarui", "fa-circle-check");
  });

  modal.classList.add("open");
}

/* ---------------------------------------------------------------------
   20B. KELOLA SEWA DESAIN & PAKET HARGA (Admin)
--------------------------------------------------------------------- */
function bindPackageDashHandlers() {
  const addBtn = document.getElementById("addPkgBtn");
  if (addBtn) {
    addBtn.addEventListener("click", () => {
      const nama = document.getElementById("addPkgNama").value.trim();
      const harga = Number(document.getElementById("addPkgHarga").value);
      const badge = document.getElementById("addPkgBadge").value.trim();
      const fitur = document.getElementById("addPkgFitur").value.split("\n").map(f => f.trim()).filter(Boolean);
      const populer = document.getElementById("addPkgPopuler").checked;
      if (!nama || !harga) { showToast("Lengkapi nama dan harga paket", "fa-triangle-exclamation"); return; }
      addPackage({ name: nama, price: harga, badge, popular: populer, features: fitur });
      renderPackages();
      renderDashboard("sewa");
      showToast("Paket berhasil ditambahkan", "fa-circle-check");
    });
  }

  document.querySelectorAll("[data-editpkg]").forEach(btn => {
    btn.addEventListener("click", () => openEditPackageModal(btn.dataset.editpkg));
  });
  document.querySelectorAll("[data-delpkg]").forEach(btn => {
    btn.addEventListener("click", () => {
      if (!confirm("Yakin ingin menghapus paket ini?")) return;
      deletePackage(btn.dataset.delpkg);
      renderPackages();
      renderDashboard("sewa");
      showToast("Paket dihapus", "fa-trash");
    });
  });

  const resetBtn = document.getElementById("resetPkgBtn");
  if (resetBtn) {
    resetBtn.addEventListener("click", () => {
      if (!confirm("Kembalikan semua paket ke pengaturan default? Perubahan yang sudah kamu buat akan hilang.")) return;
      resetPackagesToDefault();
      renderPackages();
      renderDashboard("sewa");
      showToast("Paket dikembalikan ke default", "fa-rotate-left");
    });
  }
}

function openEditPackageModal(id) {
  const pkg = PACKAGES.find(p => p.id === id);
  if (!pkg) return;
  const modal = document.getElementById("editProductModal");
  const box = document.getElementById("editProductModalBox");
  box.innerHTML = `
    <button class="modal-close" id="editPkgCloseBtn"><i class="fa-solid fa-xmark"></i></button>
    <div class="product-detail-body">
      <h2 style="margin-bottom:16px;"><i class="fa-solid fa-pen"></i> Edit Paket Sewa</h2>
      <div class="form-group"><label>Nama Paket</label><input type="text" id="editPkgNama" value="${pkg.name.replace(/"/g,'&quot;')}"></div>
      <div class="form-group"><label>Harga (Rp)</label><input type="number" id="editPkgHarga" value="${pkg.price}"></div>
      <div class="form-group"><label>Label Badge (opsional)</label><input type="text" id="editPkgBadge" value="${(pkg.badge || "").replace(/"/g,'&quot;')}"></div>
      <div class="form-group"><label>Daftar Fitur (satu baris = satu fitur)</label><textarea id="editPkgFitur" rows="5">${pkg.features.join("\n")}</textarea></div>
      <div class="form-group"><label><input type="checkbox" id="editPkgPopuler" style="width:auto;" ${pkg.popular ? "checked" : ""}> Tandai sebagai paket populer</label></div>
      <div class="detail-actions">
        <button class="btn btn-primary" id="editPkgSaveBtn"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
        <button class="btn btn-outline" style="background:rgba(0,191,255,0.14);color:var(--text-dark);" id="editPkgCancelBtn">Batal</button>
      </div>
    </div>
  `;

  box.querySelector("#editPkgCloseBtn").addEventListener("click", closeAllModals);
  box.querySelector("#editPkgCancelBtn").addEventListener("click", closeAllModals);
  box.querySelector("#editPkgSaveBtn").addEventListener("click", () => {
    const nama = box.querySelector("#editPkgNama").value.trim();
    const harga = Number(box.querySelector("#editPkgHarga").value);
    if (!nama || !harga) { showToast("Lengkapi nama dan harga paket", "fa-triangle-exclamation"); return; }
    savePackageOverride(id, {
      name: nama,
      price: harga,
      badge: box.querySelector("#editPkgBadge").value.trim(),
      popular: box.querySelector("#editPkgPopuler").checked,
      features: box.querySelector("#editPkgFitur").value.split("\n").map(f => f.trim()).filter(Boolean)
    });
    renderPackages();
    closeAllModals();
    renderDashboard("sewa");
    showToast("Paket berhasil diperbarui", "fa-circle-check");
  });

  modal.classList.add("open");
}

/* ---------------------------------------------------------------------
   21. INISIALISASI WEBSITE
--------------------------------------------------------------------- */
async function initWebsite() {
  loadSiteOverrides();
  loadBanners();
  loadGallery();
  loadTestimonials();
  loadPackages();
  applyConfig();
  applyPageText();
  bindWaButtons();
  renderHero();
  renderQuickCategories();
  renderPackages();
  renderTestimonials();
  renderGalleryPreview();
  renderGalleryFilter();
  renderGalleryGrid();
  renderOrderTimeline();
  renderPaymentMethods();
  renderCategoryTabs();
  updateCartUI();

  // Produk dimuat dari products-data.js (ditanam langsung di halaman) supaya
  // website tetap berfungsi walau dibuka langsung dari file (tanpa server).
  if (typeof PRODUCTS_DATA !== "undefined" && Array.isArray(PRODUCTS_DATA)) {
    ALL_PRODUCTS = PRODUCTS_DATA.map(p => ({ ...p }));
  } else {
    // fallback: kalau products-data.js tidak termuat, coba fetch products.json
    // (hanya berfungsi saat website dijalankan lewat server/hosting, bukan file lokal)
    try {
      const res = await fetch("products.json");
      ALL_PRODUCTS = await res.json();
    } catch (err) {
      console.error("Gagal memuat data produk:", err);
      ALL_PRODUCTS = [];
      showToast("Gagal memuat data produk", "fa-triangle-exclamation");
    }
  }

  // gabungkan produk yang diupload admin lewat Dashboard (tersimpan di LocalStorage,
  // termasuk fotonya dalam format base64) dengan produk dari products.json
  const customProducts = Storage.get("gda_custom_products", []);
  ALL_PRODUCTS = ALL_PRODUCTS.concat(customProducts);

  // terapkan foto & data pengganti (jika admin pernah mengedit produk manapun)
  applyProductOverrides();

  // buang produk yang pernah dihapus admin lewat Dashboard
  const deletedIds = Storage.get("gda_deleted_products", []);
  ALL_PRODUCTS = ALL_PRODUCTS.filter(p => !deletedIds.includes(p.id));

  renderHomeGrids();
  renderCatalog();

  // buka halaman sesuai hash awal (jika ada)
  const initialHash = window.location.hash.replace("#", "");
  const validPages = ["home","produk","sewa","testimoni","galeri","cara-order","tentang","kontak","login"];
  if (validPages.includes(initialHash)) goToPage(initialHash);
}

document.addEventListener("DOMContentLoaded", initWebsite);
